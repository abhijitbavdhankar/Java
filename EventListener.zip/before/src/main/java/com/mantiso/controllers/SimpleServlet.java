package com.mantiso.controllers;

import javax.servlet.RequestDispatcher;
//import javax.jws.soap.InitParam;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebInitParam;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//import com.mantiso.models.ApplicationSettings;
//import com.mantiso.models.CssClass;
import com.mantiso.models.User;
//import com.mantiso.models.Tab;
import java.io.IOException;
//import java.util.ArrayList;
//import java.util.HashMap;
//import java.util.List;
//import java.util.Map;


@WebServlet(urlPatterns = {"/home", "*.do"}, name="SimpleServlet", initParams = {@WebInitParam(name = "ProductName", value="Welcome Application")})
public class SimpleServlet extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String appName = "My Application";
	
    @Override
    public void init() throws ServletException {
    	
    	/*ApplicationSettings applicationSettings = new ApplicationSettings("brownUser");
        CssClass cssClass = new CssClass();
        cssClass.setName("yellowUser");
        applicationSettings.setFormCssClass1(cssClass);
                
        List<Tab> tabs = new ArrayList<>();
        tabs.add(new Tab("Signin", "#signin"));
        tabs.add(new Tab("Home", "#home"));
        tabs.add(new Tab("Profile", "#profile"));
        tabs.add(new Tab("Messages", "#messages"));
        tabs.add(new Tab("Settings", "#settings"));
        applicationSettings.setTabs(tabs);
        
        String[] tabNames = {"SignIn", "Home", "Profile", "Settings"};
        applicationSettings.setTabNames(tabNames);
        
        getServletContext().setAttribute("app", applicationSettings);    */	
    	
        appName = getServletContext().getInitParameter("ProductName");        
    	//appName = getInitParameter("ProductName");                  
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String name = request.getParameter("name");
        if(name != null) {
        	response.setContentType("text/xml");
        	response.getWriter().printf("<application>" +
                    "<name>Hello %s</name>" +
                    "<product>%s</product>" +
                    "</application>", name, appName);
        } else {
        	response.getWriter().write("Please enter a name");
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
    {
        String name = request.getParameter("name");
        String email = "a@b.com";
        RequestDispatcher rd = null;
        
        User user = new User(name, email);
        
        if(name != null && name != "")
        {
        	rd = getServletContext().getRequestDispatcher("/index.jsp");
        	request.setAttribute("user", user);
        	request.getSession().setAttribute("user", user);
        	response.getWriter().printf("Hello %s", name);
        } 
        else 
        {
        	name = (String)request.getSession().getAttribute("user");
        	rd = getServletContext().getRequestDispatcher("/index.jsp");
        	request.setAttribute("user", user);
        	request.getSession().setAttribute("user", user);
        	//response.sendRedirect("index.jsp");
        }
        rd.forward(request, response);
    }
}

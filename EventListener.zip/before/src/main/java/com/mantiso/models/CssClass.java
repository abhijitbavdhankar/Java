package com.mantiso.models;

public class CssClass {

	private String name;

    public String getName()
    {
        return name;
    }
    public void setName(String value)
    {
        name = value;
    }
    
    //<!-- ${ app["formCssClass"] },${app.formCssClass}-->
}

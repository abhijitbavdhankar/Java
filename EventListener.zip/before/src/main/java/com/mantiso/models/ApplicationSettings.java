package com.mantiso.models;

import java.util.List;
//import java.util.Map;

public class ApplicationSettings
{
	private String formCssClass = "yellowUser";
	private CssClass formCssClass1;
	private String[] tabNames;
	private List<Tab> tabs;
	
	public ApplicationSettings(String formCssClass){
			this.formCssClass = formCssClass;
		}
	
	public void setFormCSSClass(String formCssClass) 	{ 
		this.formCssClass =  formCssClass; 	
	}
	
	public String getFormCSSClass() 	{ 
		return formCssClass; 	
	}

    public CssClass getFormCssClass1(){
        return formCssClass1;
    }
    
    public void setFormCssClass1(CssClass value){
        this.formCssClass1 = value;
    } 
	
    public String[] getTabNames(){
        return tabNames;
    }
    
    public void setTabNames(String[] names){
        tabNames = new String[names.length];
        System.arraycopy(names, 0, tabNames,0 , names.length);
    }
    
    public List<Tab> getTabs() {
    	return tabs;
    }
    
    public void setTabs(List<Tab> tabs) {
    	this.tabs = tabs;
    }
}
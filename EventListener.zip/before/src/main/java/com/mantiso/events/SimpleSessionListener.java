package com.mantiso.events;

//import javax.servlet.ServletContext;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SimpleSessionListener implements HttpSessionListener {

    private static final Logger logger = Logger.getLogger("SimpleSessionListener");

    @Override
    public void sessionCreated(HttpSessionEvent se) {
        se.getSession().getServletContext().log("Session Initialised");
        logger.log(Level.INFO, "SimpleSessionListener logger Session Initialised");
    }

    @Override
    public void sessionDestroyed(HttpSessionEvent se) {
        se.getSession().getServletContext().log("Session Destroyed");
        logger.log(Level.INFO, "SimpleSessionListener logger Session Destroyed");
    }
}

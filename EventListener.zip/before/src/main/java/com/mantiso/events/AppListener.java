package com.mantiso.events;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
//import javax.servlet.annotation.WebListener;
import java.util.logging.Level;
import java.util.logging.Logger;


public class AppListener implements ServletContextListener {

    private static final Logger logger = Logger.getLogger("AppListener");

    @Override
    public void contextInitialized(ServletContextEvent event) {

        ServletContext ctx = event.getServletContext();
        ctx.log("Context initialised");
        String productName = event.getServletContext().getInitParameter("ProductName");
        ctx.log("Context initialised: " + productName);
        logger.log(Level.INFO, "AppListener logger Context Intialized");
    }

    @Override
    public void contextDestroyed(ServletContextEvent event) {

        ServletContext ctx = event.getServletContext();
        ctx.log("Context Destroyed");
        logger.log(Level.INFO, "AppListener logger Context Destroyed");
    }
}

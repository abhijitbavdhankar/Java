package com.mantiso.events;

import javax.servlet.ServletRequestEvent;
import javax.servlet.ServletRequestListener;
import java.util.logging.Level;
import java.util.logging.Logger;

public class SimpleRequestListener implements ServletRequestListener {

    private static final Logger logger = Logger.getLogger("SimpleRequestListener");

    @Override
    public void requestDestroyed(ServletRequestEvent sre) {
        sre.getServletContext().log("Request Destroyed");
        logger.log(Level.INFO, "SimpleRequestListener logger Request Destroyed");
    }

    @Override
    public void requestInitialized(ServletRequestEvent sre) {
        sre.getServletContext().log("Request Initialized");
        logger.log(Level.INFO, "SimpleRequestListener logger Request Intialized");
    }
}

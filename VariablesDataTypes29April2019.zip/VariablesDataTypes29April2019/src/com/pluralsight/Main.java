package com.pluralsight;
import com.pluralsight.flights.CargoFlights;
import com.pluralsight.flights.Flights;
import com.pluralsight.flights.Passengers;

import java.io.Reader;
import java.io.Writer;
import java.lang.*;
import java.io.BufferedReader;
import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.NotSerializableException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Deque;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.HashSet;
import java.util.InvalidPropertiesFormatException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.NavigableSet;
import java.util.PriorityQueue;
import java.util.Properties;
import java.util.Queue;
import java.util.Set;
import java.util.SortedSet;
import java.util.Stack;
import java.util.TreeSet;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.ConsoleHandler;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import static com.pluralsight.ThreadingConcurrencyExample.*;

/*
----------Single Type Import--------
import com.pluralsight.Flights;
import com.pluralsight.bar.Food;
import com.pluralsight.bar.Wine;

----------Import on demand----------
import com.pluralsight.Flights.*;
import com.pluralsight.bar.*;
*/



public class Main {

    //Log Management System
    //Logger
    //static Logger logger = LogManager.getLogManager().getLogger(Logger.GLOBAL_LOGGER_NAME);
    static Logger pkglogger = Logger.getLogger("com.pluralsight");
    static Logger logger = Logger.getLogger("com.pluralsight");
    static Logger loggerpluralsight = Logger.getLogger("com.pluralsight");
    //static Logger logger = Logger.getLogger("com.pluralsight");

    // create an enum
    public enum enumNumbers {
        ONE, TWO, THREE, FOUR, FIVE
    };

    public static void main(String[] args)
    {
        logger.log(Level.INFO,"Configuration File Logging");
        //C:\>java -Djava.util.logging.config.file=log.properties com.pluralsight.Main

        Handler h = new ConsoleHandler();
        h.setLevel(Level.ALL);
        //SimpleFormatter f = new SimpleFormatter();
        h.setFormatter(new SimpleFormatter());
        logger.addHandler(h);
        logger.setLevel(Level.ALL);
        logger.log(Level.INFO, "We are Logging using Handler-ConsoleHandler,Formatter-SimpleFormatter");

        //Commnad Line
        //java -D java.util.logging.SimpleFormatter.format = %5$s,%2$s,%4$s%n com.pluralsight.Main INFO Msg

        //Log Configuration Info into a File to set Log system
        //java.util.logging.config.file -D set property to name of the file to read info from file

        try
        {
            //------------------------Main function starts
            //logger.setLevel(Level.INFO); //logger.setLevel capture every log entry equal or greater than INFO(SEVERE, WARNING,INFO)
            //logger.setLevel(Level.FINEST);
            logger.setLevel(Level.ALL); //Logger capture everything
            //logger.setLevel(Level.OFF); //Logger capture nothing
            //doWorkPreciseConvenienceMethods();

            //CommandLine
            if (args.length < 1) {
                System.out.println("No arguments provided");
            } else {
                for (String word : args)
                    System.out.println(word);
            }

            if(args.length == 0) {
                showUsage();
                return;
            }

            String filename = args[0];
            if(!Files.exists(Paths.get(filename))) {
                System.out.println("\n File not found: " + filename);
                return;
            }
            showFileLines(filename);

            //Properties - text, XML
            System.out.println("Properties");
            Properties p = new Properties(); //key value separated by whitespce/=/: and Comments - #/!
            p.setProperty("displayName","Abhijit Dilip Bavdhankar");
            p.setProperty("accountNumber","11-22-33-44");
            String s = p.getProperty("A");
            System.out.println(s);
            String nextPosition = p.getProperty("position","1");

            try(Writer w = Files.newBufferedWriter(Paths.get("xyz.properties")))
            {
                p.store(w,"My Comment");
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            Properties p1 = new Properties();
            try(Reader r = Files.newBufferedReader(Paths.get("myapp.properties")))
            {
                p1.load(r);
            }
            String val1 = p1.getProperty("val1");
            String val2 = p1.getProperty("val2");
            String val3 = p1.getProperty("val3");
            String val4 = p1.getProperty("val4");
            System.out.println(val1);
            System.out.println(val2);
            System.out.println(val3);
            System.out.println(val4);

            System.out.println("XML");
            try(OutputStream outputStream = Files.newOutputStream(Paths.get("properties.xml")))
            {
                p.storeToXML(outputStream,"My Comment");
            }
            Properties p2 = new Properties();
            try(InputStream inputStream = Files.newInputStream(Paths.get("properties.xml")))
            {
                p2.loadFromXML(inputStream);
            }
            String val5 = p2.getProperty("displayName");
            String val6 = p2.getProperty("accountNumber");
            System.out.println(val5);
            System.out.println(val6);

            //Default properties passed to constructor will ake precedent over default properties passed to getProperty method
            //Default property file as part of package
            //Can Load from package - getResourceAsStream, can access from any class
            //Class has Class descriptor - ClassName.class/this.getClass()

            Properties defaultProps = new Properties();
            //try(InputStream inputStream = Main.class.getResourceAsStream("MyDefaultValues.xml");) //isFirstRun-Y
            try(InputStream inputStream = Files.newInputStream(Paths.get("MyDefaultValues.xml"))) //isFirstRun-Y
            {
                defaultProps.loadFromXML(inputStream);
            }
            catch (IOException e) {
                System.out.println("Exception <" + e.getClass().getSimpleName() + "> " + e.getMessage());
            }
            catch (Exception e)
            {
                e.printStackTrace();
            }

            Properties userProps = new Properties(); //Default properties passed to constructor
            userProps = defaultProps;
            userProps = loadUserProps(userProps); //isFirstRun-N

            String welcomeMessage = userProps.getProperty("welcomeMessage");
            String farewellMessage = userProps.getProperty("farewellMessage");

            System.out.println(welcomeMessage);
            System.out.println(farewellMessage);

            String isFirstRun = userProps.getProperty("isFirstRun");

            if(isFirstRun == "Y") {
                userProps.setProperty("welcomeMessage", "Welcome back");
                userProps.setProperty("farewellMessage", "Things will be familiar now");
                userProps.setProperty("isFirstRun", "N");
                saveUserProps(userProps);
            }
            else
                System.out.println(welcomeMessage);

            Properties defaults1 = new Properties();
            defaults1.setProperty("position", "1");
            Properties props = new Properties(defaults1);
            String nextPos = props.getProperty("position");
            System.out.println("position:" + nextPos);
            int iPos = Integer.parseInt(nextPos);
            props.setProperty("position", Integer.toString(++iPos));
            nextPos = props.getProperty("position");
            System.out.println("nextPosition:" + nextPos);

            //Class Loading- CLASSPATH variable
            //Windows - java -cp \pdir;\libdir com.pluralsight.Main
            //Linux - java -cp /pdir:/libdir com.pluralsight.Main
            //Windows - java -cp \pdir\training.jar;\libdir com.pluralsight.Main
            //Linux - java -cp /pdir/training.jar:/libdir com.pluralsight.Main
            //java -jar locks down class loading,no other class loading source is used
            //java -jar ouapp.jar

            //Apps often needs environment information - User information,System information,
            //Application specific information,Java configuration information
            //1.System properties - System.getProperty - Environment
            //User, Java installation information, OS configuration information
            //2.Environment variables - Configuration, App-specific variables
            String userName = System.getProperty("user.name");
            String userHome = System.getProperty("user.home");
            String userDirectory = System.getProperty("user.dir");
            String osName = System.getProperty("os.name");
            String osVersion = System.getProperty("os.version");
            String osArchitecture = System.getProperty("os.architecture");
            String javaVendor = System.getProperty("java.vendor");
            String javaVersion = System.getProperty("java.version");
            String javaVersionURL = System.getProperty("java.version.url");
            System.out.println(userName);
            System.out.println(userHome);
            System.out.println(userDirectory);
            System.out.println(osName);
            System.out.println(osVersion);
            System.out.println(osArchitecture);
            System.out.println(javaVendor);
            System.out.println(javaVersion);
            System.out.println(javaVersionURL);

            Map<String,String> mapStringEnvironmentVariables = System.getenv();
            String computerName = System.getenv("COMPUTERNAME");
            String systemRoot = System.getenv("SystemRoot");
            String courseAuthor =  System.getenv("COURSE_AUTHOR");
            System.out.println(computerName);
            System.out.println(systemRoot);
            System.out.println(courseAuthor);

            //Log System Management - Capture App activity - Record unusual circumstances/errors, Track usage information, Debug, Has Levels - Newly deployed app, Lots of details, Less details - App is mature and stable
            //java.util.logging - LogManager Class - one Global instance, getLogManager static method
            //Log system is centrally managed - There is one app-wide log manager,Manages log system configuration, Manages objects that do actual logging
            //Logger Class - Provides Logging methods, Access Logger instances with LogManager Class using getLogger method,Each instance is named
            //A global Logger instance is available,Access using Logger classic static field GLOBAL_LOGGER_NAME
            //Stub it out
            System.out.println("LogManager");
            LogManager lm = LogManager.getLogManager();
            Logger logger1 =  lm.getLogger(Logger.GLOBAL_LOGGER_NAME);
            logger1.log(Level.INFO, "My first log message");
            logger1.log(Level.INFO, "Application Main");
            System.out.println("static Logger");
            logger.log(Level.INFO, "My second log message"); //static Logger
            logger.log(Level.INFO, "Another message");

            //Level - controls logging detail
            //Each log entry is associated with a Level,Included with each log call
            //Each Logger has a capture Level,Use setLevel method,Ignores log entries below capture Level
            //Each Level has a numeric value
            //7 basic log levels - SEVERE, WARNING, INFO, CONFIG,FINE, FINER, FINEST
            //2 special levels for Logger - ALL(Integer.MIN_VALUE), OFF(Integer.MAX_VALUE)
            //Custom levels defined - conflict subsystem needs error handling
            //Logger supports several Types of Logging methods
            //1.Simple Log method - infers Class and method name
            //2.Level convenience methods - Method name implies log level - infers Class and method name
            //3.Precise Log method - Standard log methods sometimes infers wrong calling info, Logp(Class,method name)
            //4.Precise convenience methods - Simplify logging common method actions,Logs a predefined message, Always logged as LEVEL.FINER
            //Methods - entering(logs message ENTRY), exiting(logs message RETURN)
            //5.Parameterized message methods - message parameters,Parameter substation indicators explicitly appear within the message
            //Use positional substitution
            //Zero-based index within brackets {N}
            //entering, exiting
            //Methods -log,logp
            //Values appears after default message and Space separated
            //Values passed as Object/Object Array

            logger.log(Level.SEVERE, "Serious failure message"); //static Logger
            logger.log(Level.WARNING, "Potential problem message");
            logger.log(Level.INFO, "General information");
            logger.log(Level.CONFIG, "Configuartion information");
            logger.log(Level.FINE, "General developer information");
            logger.log(Level.FINEST, "Specialized developer information");

            logger.severe("Level convenience method - Serious failure message");
            logger.warning("Potential problem message");
            logger.info("General information");
            logger.config("Configuartion information");
            logger.fine("General developer information");
            logger.finest("Specialized developer information");

            logger.logp(Level.SEVERE,"com.pluralsight.Main","Main","Precise Log method - Serious failure message");
            logger.logp(Level.WARNING,"com.pluralsight.Main","Main","Potential problem message");
            logger.logp(Level.INFO,"com.pluralsight.Main","Main","General information");
            logger.logp(Level.CONFIG,"com.pluralsight.Main","Main","Configuartion information");
            logger.logp(Level.FINE,"com.pluralsight.Main","Main","General developer information");
            logger.logp(Level.FINEST,"com.pluralsight.Main","Main","Specialized developer information");

            logger.logp(Level.SEVERE,"com.pluralsight.Other","doWork","Precise convenience methods - Empty Function");

            Other other = new Other();
            other.doWork();

            logger.log(Level.INFO, "{0} is my favorite","JAVA");
            logger.log(Level.INFO, "{0} is {1} DAYS FROM {2}",new Object[]{"Wed", 2, "Fri"});

            other.doWork("Jim","Wilson");

            //Log System Components
            //1.Logger - Accept app calls , Logger.getLogger, named with String, LogManager
            //2.Handler - publishes information,Logger can have multiple Handlers, Log.addHandler
            //3.Formatter - Formats log info for publication,Each Handler has 1 Formatter,Handler.setFormatter, SimpleFormatter(Text),XMLFormatter

            //For Logger class Log method calls, Logger class generates instance of LogRecord has to info logged, we need Handler to publish that,
            //LogRecord passed to Handler.Each Hanlder has Formatter, LogRecord is passed to Formatter
            //Formatter constructs String(XML/Text) from info,String is passed to Handler then to outside world(Console,File,Network)
            //Logger can have multiple Handlers
            //Logger supports set Levels to restrict what gets logged, belowLevel is ignored
            //Handler can have set Levels for more restructive than Logger
            //1.ConsoleHandler - writes to system.err
            //2.StreamHandler - writes to OutputStream
            //3.SocketHandler - hostname, port number, writes to network socket
            //4.FileHandler - writes to 1/more files,working with rotating set of files - specify maximum size in  bytes,file numbers,Cycles through end,clears file and reusing oldest files
            //FileHandler Substitution Pattern - identify file names, Reduces system issues (like directory name and directory formats)and configuration differences,How to name Automates rotating file set namimg
            //FileHandler Substitution Pattern Values
            //1.Value(/) means Platform\backslash,Automatic conversion for (Windows/Unix) .\foo.log
            //2.Value(%t) means Temp directory,Automatic conversion for (Windows/Unix) %t/foo.log - C:\Users\Jim\AppData\Local\Temp\foo.log
            //3.Value(%h) means home directory,Automatic conversion for (Windows/Unix) %h/foo.log, C:\Users\Jim\foo.log
            //4.Value(%g) means Rotating log generation, foo_%g.log(foo_0.log, foo_1.log, foo_2.log)
            //Formatter
            //1.SimpleFormatter(Text) - java.util.logging.SimpleFormatter.format, Launch program with Java _D option
            // String.Format(format,date,source,logger, level, message, thrown),
            // String.Format
            // %1$tb - positional notation
            // %2$s - source is class and method
            // %n - new line
            // %4$s - Log Level
            // %5$s - message
            // %6$s - thrown, log Exception info
            // %n - new line
            //2.XMLFormatter(root element is log and each entry in element as record)

            Handler h1 = new ConsoleHandler();
            SimpleFormatter f = new SimpleFormatter();
            //Formatter  f1 = new SimpleFormatter();
            h1.setFormatter(f);
            loggerpluralsight.addHandler(h);
            loggerpluralsight.setLevel(Level.INFO);
            loggerpluralsight.log(Level.INFO,"We are Logging using Handler-ConsoleHandler,Formatter-SimpleFormatter");

            FileHandler fh = new FileHandler("%h/myapp_%g.log", 10, 5);
            fh.setFormatter(new SimpleFormatter());
            loggerpluralsight.addHandler(fh);
            loggerpluralsight.setLevel(Level.INFO);
            loggerpluralsight.log(Level.INFO,"We are Logging using Handler-FileHandler - Logging1");
            loggerpluralsight.log(Level.INFO,"FileHandler - We are Logging2");
            loggerpluralsight.log(Level.INFO,"FileHandler - We are Logging3");
            loggerpluralsight.log(Level.INFO,"FileHandler - We are Logging4");

            //Commnad Line
            //java -D java.util.logging.SimpleFormatter.format = %5$s,%2$s,%4$s%n com.pluralsight.Main INFO Msg

            //Log Configuration Info into a File to set Log system
            //java.util.logging.config.file -D set property to name of the file to read info from file

        }
        catch (InvalidPropertiesFormatException e) {

            System.out.println("Exception <" + e.getClass().getSimpleName() + "> " + e.getMessage());
        }
        catch (IOException e) {
            System.out.println("Exception <" + e.getClass().getSimpleName() + "> " + e.getMessage());
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }

        /* write your code here */

        try {

            //---------------  VARIABLES DATA TYPES ------------
            VariableTypes v = new VariableTypes();
            v.OPERATORPRECEDENCE();
            v.CONDITIONALOPERATOR();
            v.TYPECasting();
            v.ARRAYS();

            int num1 = 1;
            int num2 = 2;
            v.swap(num1, num2);

            //--------------- FibonacciSeries ------------
            FibonacciSeries f = new FibonacciSeries();
            f.FibonacciSeriesWhileLoop();
            f.FibonacciSeriesDoWhileLoop();
            f.FibonacciSeriesForLoop();

            //---------- Air Flight -----------------------
            Flights f1 = new Flights(10);
            String sroute = "NYToSF";
            f1.addFlightRoute(sroute);
            f1.add1Passenger();
            f1.printFlightDetails();

            Flights f11 = new Flights(11);
            sroute = "NYToLA";
            f11.addFlightRoute(sroute);
            f11 = f1;
            f11.printFlightDetails();

            f1.add1Passenger();
            f1.add1Passenger();
            f1.printFlightDetails();

            Flights f2 = new Flights(11);
            sroute = "NYToMN";
            f2.addFlightRoute(sroute);
            f2.add1Passenger();
            f2.add1Passenger();
            f2.printFlightDetails();

            //Flight Combined
            Flights f3 = null;

            if (f1.checkFlightHasSeats(f2))  //Flights f3 =  new Flights();
                f1.createNewFlightWithBoth(f2);

            if (f3 != null)
                System.out.println("Flight Combined");

            //Add Passengers to Flights
            Passengers p1 = new Passengers(1);
            Passengers p2 = new Passengers(1, 3);
            Passengers p3 = new Passengers(0, 1);
            Passengers p4 = new Passengers(0, 2);

            f1.add1Passenger();
            ;
            f1.add1Passenger(2);
            f1.add1Passenger(p1);
            f1.add1Passenger(1, 1);
            f1.add1Passenger(p2, 1);

            short Bags = 2;
            f1.add1Passenger(Bags, 2);
            ; //call int bags, int carryons

            //Flights Swapped
            System.out.println("------------Original Flights values: ---------------");
            f1.printFlightDetails();
            f2.printFlightDetails();

            f1.swap(f1, f2);

            System.out.println("--------Values after Flights swap: ---------------");
            f1.printFlightDetails();
            f2.printFlightDetails();

            System.out.println("--------Values after Flights Numbers swap: ---------------");
            f1.swapFlightNumbers(f1, f2);
            System.out.println(f1.getFlightNumber());
            System.out.println(f2.getFlightNumber());

            f1.add1Passenger((new Passengers[]{p3, p4}));
            f1.add1Passenger(p3, p4);

            //CargoFlighhts
            CargoFlights cf = new CargoFlights();
            cf.add1Package(1.0, 2.0, 3.6);
            cf.add1Passenger(p1);

            Flights f4 = new CargoFlights();  //can be assigned to base class typed references
            f4.add1Passenger(p2);

            Flights[] squadron = new Flights[5];
            squadron[0] = new Flights();
            squadron[1] = new CargoFlights();
            squadron[2] = new Flights();
            squadron[3] = new CargoFlights();
            squadron[4] = new CargoFlights();

            Flights f5 = new Flights();
            System.out.println("Seats are: " + f5.getSeats());
            CargoFlights cf2 = new CargoFlights();
            System.out.println("Seats are: " + cf2.getSeats());
            Flights f6 = new CargoFlights();
            System.out.println("Seats are: " + f6.getSeats());

            Object[] stuff = new Object[3];
            stuff[0] = new Flights();
            stuff[1] = new Passengers(0, 2);
            stuff[2] = new CargoFlights();
            Object obj = new Passengers(0, 2);
            ;
            obj = new Flights[5];
            obj = new CargoFlights();
            CargoFlights cf3 = (CargoFlights) obj;

            if (obj instanceof CargoFlights) {
                cf3.add1Passenger(p1);
                cf3.add1Package(1.0, 2.0, 4.0);
                //System.out.println("Seats are: " + obj.getSeats());
            }

            CargoFlights cf4 = cf3;
            if (cf4.equals(cf3))
                System.out.println("Equal Flights");

            if (f1.equals(p1))
                System.out.println("Equal Flights");
            else
                System.out.println("Not Equal Flights");

        /*----------PACKAGES-----------------------------------------------------------
        Package name is part of the Type name
        Class is part of Package name
        Package is part of Class name
        Reverse domain naming

        Type name is qualified by Package name
        There is a class com.pluralsight.Flights
        */

            //com.pluralsight.flights.Flights packageClass = new com.pluralsight.flights.Flights(14);
            //packageClass.getSeats();

        /*
        Fully qualified our all type names
        Compiler needs to know each type's package
        Explicitly qualifying each type is impractical
        Hard to read and time-consuming
        Java offers Alternatives to Explicitly qualifying types
        Use simple type's name
        1.Types in current package do not need to be qualified
        2.Types in java.lang do not need to be qualified
        Example - Object, String, StringBuilder, primitive wrapper classes
        3.Type imports - guide compiler to map simple names to qualified names

        Type Imports
        1.Single Type Import
        Provides mapping for a single type
        import com.pluralsight.Flights;
        Automaticaaly by IDE
        Third party pacakage
        Example package.com.pluralsight.bar;

        import com.pluralsight.bar -  Food and Wine class;
        import com.pluralsight.Flights.Food;
        import com.pluralsight.Flights.Accessory;

        Food fn -  new Food();
        Accessory a = new Accessory();

        2.Import on demand
        Provides mapping for all types in a package

        import com.pluralsight.*
        import com.pluralsight.Flights.

         --------------------------------------------------
         ARCHIVE FILES = JAR FILES, COMPRESSING FILES, MANIFEST(NAME, VALUE) PAIRS -  REGARDING ARCHIVE CONTENT
         */


            //---------- Class Inheritance  -----------------------
            ClassInheritance c = new ClassInheritance();
            c.dispShape();
            Shape s = new Shape();
            s.dispShape();
            Square sq = new Square();
            sq.dispShape();
            Circle ci = new Circle();
            ci.dispShape();
            Rectangle rt = new Rectangle();
            rt.dispShape(5);

            //---------- Polymorphism -----------------------
            Bank b;
            b = new SBIBank();
            System.out.println("--------SBIBank Rate of Interest: " + b.getRateOfInterest(10000.00, 0.07));
            b = new ICICIBank();
            System.out.println("--------ICICIBank Rate of Interest: " + b.getRateOfInterest(10000.00, 0.08));
            b = new AXISBank();
            System.out.println("--------AXISBank Rate of Interest: " + b.getRateOfInterest(10000.00, 0.09));

            //-------------Object Array---------------
            MathEquations[] m = new MathEquations[4];
            m[0] = create(1, 2, 'a');
            m[1] = create(1, 2, 's');
            m[2] = new MathEquations('m', 1, 2);
            m[3] = new MathEquations('d', 1, 2);

            for (MathEquations n : m) {
                n.execute();
                System.out.println("Result is: " + n.getResult());
            }

            double leftVal = 9.0d;
            double rightVal = 2.0d;
            int leftInt = 9;
            int rightInt = 2;

            MathEquations m1 = new MathEquations('d');
            m1.execute(leftVal, rightVal);
            System.out.println("Result is: " + m1.getResult());
            m1.execute(leftInt, rightInt);
            System.out.println("Integer Result is: " + m1.getResult());
            m1.execute((double) leftInt, rightInt);
            System.out.println("Integer Result is: " + m1.getResult());
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        //----------- InputOutputStreamsFiles -----------------------------------------
        //InputOutputStreamsFiles i = new InputOutputStreamsFiles();
        //i.InputOutputStreamsFilesExample();

        //----------ThreadingConcurrencyExample------------------------------------------


        try
        {
            //System.out.println("ThreadingConcurrencyExample");
            BankExecutorsWorker();
            BankExecutorsTxWorker();
            BankExecutorsTxPromoWorker();

            //Runnable interface
            System.out.println("SingleThread");
            SingleThread();
            MultipleThread();
            ThreadingArrays();
            /*threadingConcurrencyExample.ThreadingInputOutputFilesMultipleThread();
            threadingConcurrencyExample.ThreadingArraysInputOutputFiles();;
            threadingConcurrencyExample.ThreadingInputOutputFilesExecutorsClass();

            //Callable<Integer> interface
            ThreadCallableExample threadCallableExample = new ThreadCallableExample();
            threadCallableExample.ThreadingInputOutputFilesExecutorsClassCallable();*/

            //Persisting Objects with Serialization - Save Applicationstate to file system/database and then restore it
            //Shared Memory - Pass objects from one application to another application
            //Pass over network, memory address
            //Storing object-graph to a byte stream, other reference objects
            //Types and values
            //Serizable interface has no methods
            //ObjectOutputStream -  Serializes object-graph to byte stream
            //ObjectInputStream -  DeSerializes byte stream to object-graph
            //Primitive Types are Serializable - int
            //Class Version Compatability
            //Serial version unique identifier - Structure of class/Class Version matching with Serilazable Class,added in stream content
            //private long static final
            //serialver utility - calculate initial version of type, Maintain same value for all future class versions
            //commandline -classpath, -show GUI


            BankAccount ba = new BankAccount("SavingsAccount", 100);
            ba.deposit(200);
            saveAccountSerialization(ba,"account2.dat");
            System.out.println("saveAccountDeSerialization account2.dat");
            saveAccountDeSerialization("account2.dat");
            //System.out.println("saveAccountDeSerialization account.dat");
            //saveAccountDeSerialization("account.dat");

            BankAccount ba1 = new BankAccount("ChequingAccount", 100);
            AccountGroup a = new AccountGroup();
            a.addAccount(ba);
            a.addAccount(ba1);
            AccountGroupSerialization(a, "group.dat");
            System.out.println("AccountGroupDeSerialization group.dat");
            AccountGroupDeSerialization("group.dat");

            //Collections
            System.out.println("Collections");
            Product door = new Product("Wooden Door", 35);
            Product floorPanel = new Product("Floor Panel", 25);
            Product window = new Product("Glass Window", 10);
            Product window1 = new Product("Glass Window1", 10);

            //Arrays
            Product[] productsArray = {door, floorPanel, window};
            System.out.println("Arrays");
            System.out.println(Arrays.toString(productsArray));
            //productsArray[3]=door; //ArrayIndexOutOfBoundsException - Duplicate element error

            //List - ArrayList
            List<Product> productsArrayList = new ArrayList<>();
            productsArrayList.add(door);
            productsArrayList.add(floorPanel);
            productsArrayList.add(window);
            productsArrayList.add(window1);
            productsArrayList.add(2, window);
            System.out.println("ArrayList" + productsArrayList + " " + productsArrayList.size());
            productsArrayList.add(3, window);
            productsArrayList.set(4, floorPanel);
            System.out.println("indexOf:" + productsArrayList.indexOf(door));
            System.out.println("lastIndexOf:" +productsArrayList.lastIndexOf(window));
            System.out.println("forEach");
            productsArrayList.forEach(System.out::println);
            System.out.println("productsArraySubList");
            List<Product> productsArraySubList = new ArrayList<>();
            productsArraySubList = productsArrayList.subList(0,1);
            productsArraySubList.forEach(System.out::println);

            for(int i = 0; i < productsArrayList.size() ; i++)
            {
                Product p = productsArrayList.get(i);
                System.out.println(p);
            }
            for(Product p : productsArrayList)
            {
                System.out.println(p);
            }
            productsArrayList.add(window);
            System.out.println("forEach");
            productsArrayList.forEach(System.out::println);
            System.out.println("productsArrayList1");
            List<Product> productsArrayList1 = new ArrayList<>();
            productsArrayList1.add(door);
            productsArrayList1.add(floorPanel);
            productsArrayList1.add(window);
            productsArrayList1.forEach(System.out::println);
            System.out.println("productsArrayList1 retainAll");
            productsArrayList1.retainAll(productsArrayList);
            productsArrayList1.forEach(System.out::println);

            System.out.println("Collection");
            Collection<Product> productsCollectionArrayList = new ArrayList<>(); //CollectionArrayList - Collection of collections
            productsCollectionArrayList.add(door);
            productsCollectionArrayList.add(floorPanel);
            productsCollectionArrayList.add(window);

            Collection<Product> productsCollectionArrayList1 = new ArrayList<>(); //CollectionArrayList - Collection of collections
            productsCollectionArrayList1.add(door);
            productsCollectionArrayList1.add(floorPanel);
            productsCollectionArrayList1.add(window);

            System.out.println("Iterator");
            Iterator<Product> iterator = productsCollectionArrayList.iterator();
            while (iterator.hasNext())
            {
                final Product product = iterator.next();
                if (product.getWeight() > 20)
                {
                    System.out.println(product);
                }
                else
                {
                    iterator.remove();
                }
            }

            for (Product product : productsCollectionArrayList) {
                if (product.getWeight() > 20)
                {
                    System.out.println(product);
                }
                else
                {
                    productsCollectionArrayList.remove(product);
                }
            }

            System.out.println(productsCollectionArrayList);
            System.out.println(productsCollectionArrayList.size());
            System.out.println(productsCollectionArrayList.isEmpty());
            productsCollectionArrayList.add(window);
            System.out.println(productsCollectionArrayList.contains(floorPanel));
            productsCollectionArrayList.remove(floorPanel);
            System.out.println(productsCollectionArrayList.contains(floorPanel));
            System.out.println("productsCollectionArrayList addAll");
            productsCollectionArrayList.addAll(productsCollectionArrayList1);
            productsCollectionArrayList.forEach(System.out::println);
            System.out.println(productsCollectionArrayList.containsAll(productsCollectionArrayList1));
            System.out.println("productsCollectionArrayList retainAll");
            productsCollectionArrayList.retainAll(productsCollectionArrayList1);
            productsCollectionArrayList.forEach(System.out::println);
            productsCollectionArrayList.removeAll(productsCollectionArrayList1);
            productsCollectionArrayList.forEach(System.out::println);
            System.out.println("productsCollectionArrayList1 clear");
            productsCollectionArrayList1.clear();
            productsCollectionArrayList1.forEach(System.out::println);

            ArrayListString aArrayListString = new ArrayListString();
            aArrayListString.ArrayListString();

            //ArrayList - Getting elements is specifiying index or position.
            //ArrayList - adding elements is resizing the list is more
            //ArrayList -  removing elements like head of the list is resizing the list is more
            //ArrayList/LinkedLIst are same performance for next() and contains() method
            //LinkedList - used when adding elements at start/adding/deleting elements lot,Pointers to list
            //LinkedLIst - Getting elements is traversing to list n times.
            //LinkedList - adding elements is resizing the list is less
            //LinkedList-  removing elements update the pointers to previous element

            /*
            Sets are distinct elements with no duplicates
            1.HashSet extends AbstractSet and implements the Set interface.
            It creates a collection that uses a hash table for storage.
            A hash table stores information by using a mechanism called hashing.
            In hashing, the informational content of a key is used to determine a unique value, called its hash code.
            The hash code is then used as the index at which the data associated with the key is stored.
            The transformation of the key into its hash code is performed automatically.

            2.TreeSet class implements the Set interface that uses a tree for storage.
            Uses a Binary Tree with a required sort order.SortedSet - The objects of the TreeSet class are stored in ascending order.
            It inherits AbstractSet class and implements the NavigableSet interface.

            3.EnumSet Uses a bitset based upon the ordinal of the enum
             */
            System.out.println("Set - HashSet");
            Collection<Integer> integerCollection = new ArrayList<Integer>();
            for (int i = 0; i < 10; i++)
            {
                integerCollection.add(i);
            }
            Set<Integer> baIntegerHashSet = new HashSet<Integer>();
            baIntegerHashSet.add(1);
            baIntegerHashSet.addAll(integerCollection);
            Iterator<Integer> itr = baIntegerHashSet.iterator();
            while(itr.hasNext()){
                System.out.println(itr.next());
                System.out.println(itr.hashCode());
            }
            baIntegerHashSet.remove(1);
            baIntegerHashSet.removeAll(integerCollection);

            Set<String> baHashSet = new HashSet<String>();
            baHashSet.add("A");
            baHashSet.add("B");
            Iterator<String> itr1 = baHashSet.iterator();
            while(itr.hasNext()){
                System.out.println(itr1.next());
            }

            baHashSet.remove("A");
            baHashSet.removeAll(baHashSet);

            System.out.println("TreeSet");
            Set<String> baTreeSet = new TreeSet<String>();
            Collection<String> StringCollection = new ArrayList<String>();
            StringCollection.add("A1");
            StringCollection.add("B1");
            baTreeSet.add("A");
            baTreeSet.add("B");
            baTreeSet.addAll(StringCollection);

            itr1 = baTreeSet.iterator();
            while(itr1.hasNext()){
                System.out.println(itr1.next());
            }
            baTreeSet.remove("A");
            baTreeSet.removeAll(baHashSet);

            System.out.println("EnumSet");
            EnumSet<enumNumbers> enumSet;
            enumSet = EnumSet.of(enumNumbers.ONE);
            enumSet.add(enumNumbers.TWO);
            System.out.println(enumSet);
            enumSet.remove(enumNumbers.ONE);

            System.out.println("SortedSet");
            SortedSet<BankAccount> sortedSetBankAccount = new TreeSet<BankAccount>();
            sortedSetBankAccount.add(new BankAccount("A", 100));
            sortedSetBankAccount.add(new BankAccount("B", 100));

            for(BankAccount ba01 : sortedSetBankAccount)
            {
                System.out.println("BankAccount,Accountid:" + ba01.getAccountid() + ", Balance: " + ba01.getBalance());
            }

            SortedSet<String> sortedSet1 = new TreeSet<>();
            SortedSet<Integer> sortedSet2 = new TreeSet<>();
            SortedSet<Integer> sortedSet3 = new TreeSet<>();
            SortedSet<String> sortedSet4 = new TreeSet<>();
            SortedSet<Integer> sortedSet5 = new TreeSet<>();
            SortedSet<Integer> sortedSet6 = new TreeSet<>();

            //Character/String SortedSet
            sortedSet1.add("a");
            sortedSet1.add("b");
            sortedSet1.add("a1");
            sortedSet1.add("b1");
            sortedSet1.add("c");
            sortedSet1.add("d");
            for(String str : sortedSet1)
            {
                System.out.println(str);
            }

            //Numbers SortedSet
            sortedSet3.add(22);
            sortedSet3.add(55);
            sortedSet3.add(100);
            sortedSet3.add(99);
            sortedSet3.add(19);
            sortedSet3.add(1);
            for(Integer i : sortedSet3)
            {
                System.out.println(i);
            }

            //headSet
            sortedSet2 = sortedSet3.headSet(55);
            for(Integer i : sortedSet2)
            {
                System.out.println(i);
            }

            //subSet
            sortedSet5 = sortedSet3.subSet(22,100);
            for(Integer i : sortedSet5)
            {
                System.out.println(i);
            }

            //tailSet
            sortedSet6 = sortedSet3.tailSet(10);
            for(Integer i : sortedSet6)
            {
                System.out.println(i);
            }

            //subSet
            sortedSet4 = sortedSet1.subSet("a","c"); //subSet
            for(String str : sortedSet4)
            {
                System.out.println(str);
            }

            System.out.println("NavigableSet");
            NavigableSet<Integer> navigableSet = new TreeSet();
            navigableSet.add(0);
            navigableSet.add(1);
            navigableSet.add(2);
            navigableSet.add(3);
            navigableSet.add(4);
            navigableSet.add(5);
            navigableSet.add(6);
            navigableSet.add(22);
            navigableSet.add(55);
            navigableSet.add(100);
            navigableSet.add(99);
            navigableSet.add(19);
            navigableSet.add(1);
            System.out.println("lower(9): " + navigableSet.lower(4));
            System.out.println("floor(9): " + navigableSet.floor(5));
            System.out.println("higher(1): " + navigableSet.higher(3));
            System.out.println("ceiling(1): " + navigableSet.ceiling(2));
            System.out.println("pollFirst(): " + navigableSet.pollFirst());

            System.out.println("Stack");
            Stack<String> stack = new Stack<String>();
            stack.push("Ayush");
            stack.push("Garvit");
            stack.push("Amit");
            stack.push("Ashish");
            stack.push("Garima");
            for(String str : stack)
            {
                System.out.println(str);
            }
            stack.pop(); //pop
            for(String str : stack)
            {
                System.out.println(str);
            }

            System.out.println("Queue");
            PriorityQueue<String> queue=new PriorityQueue<String>();
            queue.add("Amit Sharma");
            queue.add("Vijay Raj");
            queue.add("JaiShankar");
            queue.add("Raj");
            for(String str : queue)
            {
                System.out.println(str);
            }
            System.out.println("head:"+queue.element());
            System.out.println("head:"+queue.peek());
            queue.remove();
            queue.poll();
            for(String str : queue)
            {
                System.out.println(str);
            }

            System.out.println("Deque");
            Deque<String> deque = new ArrayDeque<String>();
            deque.add("Gautam");
            deque.add("Karan");
            deque.add("Ajay");
            for (String str : deque) {
                System.out.println(str);
            }

            deque.remove("Karan");
            for (String str : deque) {
                System.out.println(str);
            }

            //Maps-HashMaps,TreeMaps,NavigationMaps,LinkedHashMap,WeakHashMap,EnumMap

            HashMap<Integer,String> hm=new HashMap<Integer,String>();
            hm.put(100,"Amit");
            hm.put(101,"Vijay");
            hm.put(102,"Rahul");

            for(Map.Entry mapEntry : hm.entrySet())
            {
                System.out.println(mapEntry.getKey()+" "+ mapEntry.getValue());
            }

            //Update
            hm.replace(102, "Gaurav");
            for(Map.Entry mapEntry : hm.entrySet())
            {
                System.out.println(mapEntry.getKey()+" "+ mapEntry.getValue());
            }

            hm.remove(101);
            hm.remove(102, "Rahul");
            for(Map.Entry mapEntry : hm.entrySet())
            {
                System.out.println(mapEntry.getKey()+" "+ mapEntry.getValue());
            }

            //Singleton
            Set<Integer> set = Collections.singleton(1);
            List<String> list = Collections.singletonList("one");
            Map<Integer, String> map = Collections.singletonMap(1, "one");

            //EmptyCollection
            Set<Integer> set1 = Collections.emptySet();
            List<String> list1 = Collections.emptyList();
            Map<Integer, String> map1 = Collections.emptyMap();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    //Precise Convenience Methods
    public static void doWorkMainPreciseConvenienceMethods()
    {
        logger.setLevel(Level.ALL);
        logger.entering("com.pluralsight.Main","doWorkPreciseConvenienceMethods");

        //logger.logp(Level.SEVERE,"com.pluralsight.Main","doWorkPreciseConvenienceMethods","Precise Convenience method - Serious failure message");
        logger.logp(Level.WARNING,"com.pluralsight.Main","doWorkPreciseConvenienceMethods","Precise Convenience method - Potential problem message");
        //logger.logp(Level.INFO,"com.pluralsight.Main","doWorkPreciseConvenienceMethods","General information");
        //logger.logp(Level.CONFIG,"com.pluralsight.Main","doWorkPreciseConvenienceMethods","Configuartion information");
        //logger.logp(Level.FINE,"com.pluralsight.Main","doWorkPreciseConvenienceMethods","General developer information");
        //logger.logp(Level.FINEST,"com.pluralsight.Main","doWorkPreciseConvenienceMethods","Specialized developer information");

        logger.exiting("com.pluralsight.Main","doWorkPreciseConvenienceMethods");
    }

    private static void showFileLines(String filename) {
        System.out.println();

        try(BufferedReader reader = Files.newBufferedReader(Paths.get(filename))) {
            String line = null;
            while((line = reader.readLine()) != null)
                System.out.println(line);
        } catch(Exception ex) {
            System.out.println(ex.getClass().getSimpleName() + " - " + ex.getMessage());
        }
    }

    private static void showUsage() {
        System.out.println();
        System.out.println("Please provide the filename to process on the command line");
    }

    //Executors class
    public static void BankExecutorsWorker()
    {
        try
        {
            ExecutorService es = Executors.newFixedThreadPool(5); //Concurrency
            BankAccount account = new BankAccount(100);
            for(int i= 0; i< 5; i++) { //5 Worker Threads
                Worker worker = new Worker(account);
                es.submit(worker);
            }
            es.shutdown();
            es.awaitTermination(60, TimeUnit.SECONDS);

            //Concurrency Co-ordination
            //Synchronized methods - co-ordinate threads access to methods
            //Managed at class instance level
            //Class instance method is marked synchronized then it cannot be called by more than one thread/other threads
            //Use - when reading value modified by other thread,protect modification by mutiple threads
            //Has significant overheads
            //Call to method acquired lock to current object instance of Class
            //All Java objects has locks
            //Collections
            //1.Synchronized Collection wrappers
            // Eg:- Methods like SynchronizedList, SynchronizedMap
            //paased to static class we get Wrapper that is thread safe proxy thread co-ordination occurs
            //2.Blocking Collections - Producers and Consumers model
            //one or more threads produce and other threads consume
            //Consumers need to wait for content if not avaliable - Java provides blocking queues
            //Attempt to read is blocks if empty
            //Wakes up when content avaliable
            //Eg:-LinkedBlockingDeque, PriorityBlockingQueue
            //Semaphores - Mutiple threads concurrently accessing resources Limited -  3 Threads working at a time
            //java.util.concurrent
            //java.util.concurrent.atomic - Atomic Integer,Boolean
            //Eg:- set, get, getAndAdd, compareAndSet


        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void BankExecutorsTxWorker()
    {
        try
        {
            ExecutorService es = Executors.newFixedThreadPool(5); //Concurrency
            BankAccount account = new BankAccount(100);
            /*
            for(int i= 0; i< 5; i++) { //5 TxWorker Threads
                TxWorker worker = new TxWorker(account,'d',100);
                es.submit(worker);
            }*/

            TxWorker[] workers = new TxWorker[5];
            for(TxWorker worker: workers) { //TxWorker Thread
                worker = new TxWorker(account,'d',100);
                es.submit(worker);
            }

            for(TxWorker worker: workers) { //TxWorker Thread
                worker = new TxWorker(account,'w',10);
                es.submit(worker);
            }

            es.shutdown();
            es.awaitTermination(60, TimeUnit.SECONDS);

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static void BankExecutorsTxPromoWorker()
    {
        try
        {
            ExecutorService es = Executors.newFixedThreadPool(5); //Concurrency
            BankAccount account = new BankAccount(100);
            TxWorker[] workers = new TxPromoWorker[5];

            for(TxWorker worker: workers) { //TxWorker Thread
                worker = new TxPromoWorker(account,'d',100);
                //worker = (TxWorker) worker;
                es.submit(worker);
            }
            es.shutdown();
            es.awaitTermination(60, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    public static MathEquations create(double leftVal, double rightVal,char oprCode)
    {
        MathEquations m = new MathEquations();
        m.setleftVal(leftVal);
        m.setrightVal(rightVal);
        m.setoprCode(oprCode);
        return m;
    }

    //Serialization
    public static void saveAccountSerialization(BankAccount ba, String fileName)
    {

        try(ObjectOutputStream objectOutputStream = new ObjectOutputStream(Files.newOutputStream(Paths.get(fileName))))
        {
            objectOutputStream.writeObject(ba);
            System.out.println("Object Serialization");
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }

        FileOutputStream fos = null;
        ObjectOutputStream objectOutputStream = null;
        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");

        try {
            // create a new file with an ObjectOutputStream
            fos = new FileOutputStream("student.db"); //binary format, which means you cannot view its content using a text editor.
            objectOutputStream = new ObjectOutputStream(fos);

            List<Student> listStudent = new ArrayList<>();

            listStudent.add(
                    new Student("Alice", dateFormat.parse("02-15-1993"), false, 23, 80.5f));

            listStudent.add(
                    new Student("Brian", dateFormat.parse("10-03-1994"), true, 22, 95.0f));

            listStudent.add(
                    new Student("Carol", dateFormat.parse("08-22-1995"), false, 21, 79.8f));


            for (Student student : listStudent) {
                objectOutputStream.writeObject(student);
            }

            // close the stream
            fos.close();
            objectOutputStream.close();
        }
        catch (ParseException pe)
        {
            pe.printStackTrace();
        }
        catch(NotSerializableException n) {
            n.printStackTrace();
        }
        catch(EOFException e)
        {
            System.out.println("Reached end of file");
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }


    //DeSerialization
    public static void saveAccountDeSerialization(String fileName)
    {

        try(ObjectInputStream objectInputStream = new ObjectInputStream(Files.newInputStream(Paths.get(fileName))))
        {
            while (true) {
                BankAccount ba = (BankAccount) objectInputStream.readObject();
                System.out.println("Object DeSerialization");
                System.out.print(ba.getAccountid() + "\t");
                System.out.print(ba.getBalance() + "\t");
                System.out.print(ba.getlastTxType() + "\t");
                System.out.print(ba.getlastTxAmount() + "\t");
            }
        }
        catch(EOFException e)
        {
            System.out.println("Reached end of file");
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }


        FileInputStream fis = null;
        ObjectInputStream objectInputStream = null;
        DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");

        try {
            // create a new file with an ObjectOutputStream
            fis = new FileInputStream("student.db");
            objectInputStream = new ObjectInputStream(fis);


            while (true) {
                Student student = (Student) objectInputStream.readObject();

                System.out.print(student.getName() + "\t");
                System.out.print(dateFormat.format(student.getBirthday()) + "\t");
                System.out.print(student.getGender() + "\t");
                System.out.print(student.getAge() + "\t");
                System.out.println(student.getGrade());
            }

            //fis.close();
            //objectInputStream.close();
        }
        catch(EOFException e)
        {
            System.out.println("Reached end of file");
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
        catch(ClassNotFoundException e)
        {
            e.printStackTrace();
        }
    }

    public static  void AccountGroupSerialization(AccountGroup a, String fileName)
    {
        try(ObjectOutputStream objectOutputStream = new ObjectOutputStream(Files.newOutputStream(Paths.get(fileName))))
        {
            objectOutputStream.writeObject(a);
            System.out.println("Object Serialization");
        }
        catch(IOException e)
        {
            e.printStackTrace();
        }
    }


    public static void AccountGroupDeSerialization(String fileName) {

        AccountGroup a = null;

        try (ObjectInputStream objectInputStream = new ObjectInputStream(Files.newInputStream(Paths.get(fileName)))) {

            while (true) {
                a = (AccountGroup) objectInputStream.readObject();
                System.out.print(a.getTotalBalance() + "\t");
            }
        } catch (EOFException e) {
            System.out.println("Reached end of file");
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
    }

    private static Properties loadUserProps(Properties userProperties) throws IOException
    {
        Path userFile = Paths.get("userValues.xml");
        if(Files.exists(userFile)) {
            try(InputStream inputStream = Files.newInputStream(userFile)) {
                userProperties.loadFromXML(inputStream);
            }
        }

        return userProperties;
    }

    private static void saveUserProps(Properties userProps) throws IOException {
        try(OutputStream outputStream = Files.newOutputStream(Paths.get("userValues.xml"))) {
            userProps.storeToXML(outputStream, null);
        }
    }
}



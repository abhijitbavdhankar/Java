package com.pluralsight;

public class Employee implements Comparable{

    private String name;

    private int age;

    public Employee(String name, int age) {
        super();
        this.name = name;
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    @Override
    public int compareTo(Object obj) {

        //ascending order
        Employee e = (Employee) obj;
        return this.age - e.getAge();

        //descending order
        //return o.getAge() - this.age;

        //return 0;
    }
}

package com.pluralsight;

public class TxWorker implements Runnable{ //Transaction Worker

    protected BankAccount account;
    protected char txType; // ‘w’ -> withdrawal, ‘d’ -> deposit
    protected int amt;

    public TxWorker()
    {}

    public TxWorker(BankAccount account, char txType, int amt)
    {
        this.account = account;
        this.txType = txType;
        this.amt = amt;
    }

    @Override
    public void run()
    {
        try
        {
            synchronized (account) {

                String strBank = "";
                int startBalance = account.getBalance();
                strBank = " TxWorker Start Balance :" + startBalance;

                if (txType == 'w')
                    account.withdrawal(amt);
                else if (txType == 'd')
                    account.deposit(amt);

                strBank = strBank + " Transaction:" + txType;
                int endBalance = account.getBalance();
                strBank = strBank + " End Balance:" + account.getBalance();
                System.out.println(strBank + "\n");
            }

        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
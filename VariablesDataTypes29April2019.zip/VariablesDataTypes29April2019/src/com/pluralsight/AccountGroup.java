package com.pluralsight;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class AccountGroup implements Serializable {

    private Map<String, BankAccount> accountMap = new HashMap<>();

    private transient int totalBalance= 100; //transient means Do not serliaze this field

    public int getTotalBalance(){
        return  totalBalance;
    }

    public void addAccount(BankAccount ba)
    {
        totalBalance += ba.getBalance();
        accountMap.put(ba.getAccountid(),ba);
    }

    private void readObject(ObjectInputStream i) throws IOException, ClassNotFoundException
    {
        i.defaultReadObject();

        for(BankAccount ba : accountMap.values()) {
            totalBalance += ba.getBalance();
        }
    }

}

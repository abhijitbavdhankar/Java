package com.pluralsight;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;

public class Adder implements Runnable //, Callable<Integer>
{
    //VARIABLES
    private FileWriter fw = null;
    private FileReader reader = null;
    private static int total = 0;
    private String intVal = null;
    private String Inputfile, Outputfile;
    private BufferedReader br = null;
    private BufferedWriter bw = null;

    //CONSTRUCTORS
    public void Adder (){}
    public void Adder (String Inputfile){}
    public void Adder (String Inputfile, String Outputfile){}
    public Adder(String Inputfile)
    {
        this.Inputfile = Inputfile;
    }
    public Adder(String Inputfile, String Outputfile)
    {
        this.Inputfile = Inputfile;
        this.Outputfile = Outputfile;
    }

    //GET_SET ACCESSORS,MUTATORS PROPERTIES
    public String getInputfile()    {        return Inputfile;    }
    public void setInputfile(String Inputfile)    {        this.Inputfile = Inputfile;    }
    public String getOutputfile()    {        return Outputfile;    }
    public void setOutputfile(String Outputfile)    {        this.Outputfile = Outputfile;    }

    //METHODS
    public void InputOutputFiles() throws FileNotFoundException,IOException
    {
        try(BufferedReader br = new BufferedReader(new FileReader(Inputfile))) {

            System.out.println("Inputfile:" + Inputfile);
            while ((intVal = br.readLine()) != null) {
                if (intVal.isEmpty() || (intVal.length() == 0))
                    break;
                else {
                    System.out.println("intVal:" + intVal);
                    total += intVal.length();
                }
            }
            System.out.println("BufferedReader:"+ total);
        }
        System.out.println("Outputfile:" + Outputfile);
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(Outputfile, true))) {
            System.out.println("BufferedWriter:"+ total);
            bw.write(total);
        }

        //Read Output File
        System.out.println("ReadOutputfile:" + Outputfile);
        try(BufferedReader br = new BufferedReader(new FileReader(Outputfile))) {
            while ((intVal = br.readLine()) != null) {
                if (intVal.isEmpty() || (intVal.length() == 0))
                    break;
                else {
                    System.out.println("intVal:" + intVal);
                    total += intVal.length();
                }
            }
        }

        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if (br != null)
                    br.close();

                if (bw != null)
                    bw.close();
            }
            catch(IOException e2)
            {
                System.out.println(e2.getClass().getSimpleName() + " - " + e2.getMessage());
            }
        }
    }

    public void InputOutputFiles1(String Inputfile, String Outputfile) throws FileNotFoundException,IOException
    {
        try
        {
            BufferedReader br = new BufferedReader(new FileReader(Inputfile));
            BufferedWriter bw = new BufferedWriter(new FileWriter(Outputfile, true));

            int total = 0;
            String intVal = null;

            //Read Input File
            //while ((intVal = br.readLine()) != null ){
            //    System.out.print(intVal);
            //}

            //Write File
            while ((intVal = br.readLine()) != null ){
                total += Integer.parseInt(intVal);
            }
            bw.write(total);
            bw.close();
            br.close();

            //Read Output File
            //br = new BufferedReader(new FileReader(Outputfile));
            //while ((intVal = br.readLine()) != null ){
            //    System.out.print(intVal);
            //}
            //br.close();
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if (reader != null)
                    reader.close();
            }
            catch (IOException e2)
            {
                System.out.println(e2.getClass().getSimpleName() + " - " + e2.getMessage());
            }
        }
    }

    @Override
    public void run() {
        try {
            InputOutputFiles();
            //InputOutputFiles1(Inputfile, Outputfile);
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
    }
}

package com.pluralsight;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.Callable;

public class AdderCallable implements Callable<Integer> {

    //VARIABLES
    private FileWriter fw = null;
    private FileReader reader = null;
    private int total = 0;
    private String intVal = null;
    private String Inputfile, Outputfile;

    //CONSTRUCTORS
    public void Adder (){}
    public void Adder (String Inputfile){}
    public void Adder (String Inputfile, String Outputfile){}
    public AdderCallable(String Inputfile)
    {
        this.Inputfile = Inputfile;
    }
    public AdderCallable(String Inputfile, String Outputfile)
    {
        this.Inputfile = Inputfile;
        this.Outputfile = Outputfile;
    }

    //GET_SET ACCESSORS,MUTATORS PROPERTIES
    public String getInputfile()    {        return Inputfile;    }
    public void setInputfile(String Inputfile)    {        this.Inputfile = Inputfile;    }
    public String getOutputfile()    {        return Outputfile;    }
    public void setOutputfile(String Outputfile)    {        this.Outputfile = Outputfile;    }

    public int InputOutputFilesReturnResult() throws FileNotFoundException,IOException
    {
        try(BufferedReader br = new BufferedReader(new FileReader(Inputfile))) {
            while ((intVal = br.readLine()) != null ){
                total += Integer.parseInt(intVal);
            }

            return total;
        }
        catch (FileNotFoundException e)
        {
            e.printStackTrace();
        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if (reader != null)
                    reader.close();
            }
            catch (IOException e2)
            {
                System.out.println(e2.getClass().getSimpleName() + " - " + e2.getMessage());
            }

            return total;
        }
    }

    @Override
    public Integer call() throws Exception {
        return InputOutputFilesReturnResult();
    }

}

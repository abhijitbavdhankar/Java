package com.pluralsight;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.CharArrayReader;
import java.io.CharArrayWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.io.ByteArrayInputStream;

public class InputOutputStreamsFiles {

    private Writer w = null;
    private FileWriter fw = null;
    //Reader reader = null;
    private FileReader reader = null;
    private File file = new File("file1.txt");
    private int data=0, intVal= 0;
    private InputStream inputstream = null;
    private FileOutputStream outputstream = null;
    private FileInputStream fs = null;
    private InputStreamReader isr = null;
    private OutputStream outputstream1 = null;
    private OutputStreamWriter osw = null;



    public void InputOutputStreamsFilesExample()  {

        try {

            //char[] buff - FileWriter, Writer
            fw = new FileWriter("file1.txt",true);
            fw.write("FileWriter");
            fw.close();

            w = new FileWriter("file1.txt",true);
            char charA = 'a';
            w.write(charA);
            char[] charBuff = {'a','b','c'};
            w.write(charBuff);
            String str = "Writer";
            w.write(str);
            w.close();

            //InputStream - Reading one byte at a time
            System.out.println("----------InputStream");
            inputstream = new FileInputStream("file1.txt");
            data = inputstream.read();
            while (data != -1) {
                data = inputstream.read();
                System.out.print(data);
                byte byteVal = (byte) data;
                System.out.print((char) byteVal);
            }
            inputstream.close();

            System.out.println("------OutputStream");
            outputstream = new FileOutputStream("file1.txt",true);
            String content = "OutputStream";
            byte[] bytes = content.getBytes();
            outputstream.write(bytes);
            byte byteVal = 100;
            outputstream.write(byteVal);
            outputstream.close();

            //ByteArrayInputStream class allows a buffer in the memory to be used as an InputStream.
            //The input source is a byte array.
            System.out.println("------ByteArrayInputStream");
            String message = "ByteArrayInputStream";
            ByteArrayInputStream bais = new ByteArrayInputStream(message.getBytes());
            int ch;
            while ( (ch = bais.read()) != -1) {
                System.out.println((char) ch);
            }
            bais.close();
            byte[] bytesArr = "ByteArrayOutputStream".getBytes();
            ByteArrayOutputStream baos = new ByteArrayOutputStream(bytesArr.length);
            baos.write(bytesArr, 0, bytesArr.length);
            baos.close();

            //PipedInputStream
            System.out.println("-------PipedInputStream");
            PipedInputStream pipedInputStream = new PipedInputStream();
            PipedOutputStream pipedOutputStream = new PipedOutputStream();
            pipedInputStream.connect(pipedOutputStream);
            bytesArr = "PipedInputStream".getBytes();
            pipedOutputStream.write(bytesArr);
            pipedOutputStream.write(byteVal);

            for(int i=0; i <= 1; i++ )
                System.out.println((char) pipedInputStream.read());

            pipedInputStream.close();
            pipedOutputStream.close();

            //CharArrayWriter
            System.out.println("-------CharArrayWriter");
            CharArrayWriter charArrayWriter = new CharArrayWriter();
            message = "CharArrayWriter";
            charArrayWriter.write(message);
            CharArrayReader charArrayReader = new CharArrayReader(charBuff);
            intVal = 0;
            System.out.println("-------CharArrayReader");
            while ((intVal = charArrayReader.read()) >= 0) {
                char charVal = (char) intVal;
                System.out.print(charVal);
            }
            charArrayWriter.close();
            charArrayReader.close();

            //StringWriter
            System.out.println("-------StringWriter");
            StringWriter sw = new StringWriter();
            message = "StringWriter";
            sw.write(message);
            StringReader sr = new StringReader(message);
            System.out.println(sr.read());
            sw.close();
            sr.close();

            //PipedWriter
            System.out.println("-----------PipedWriter");
            PipedWriter pw = new PipedWriter();
            PipedReader pr = new PipedReader();
            pw.connect(pr);
            char[] charBuff1 = {'p','w','p','r'};
            pw.write(charBuff1);

            for(int i=0; i <=1 ; i++ )
                System.out.println((char) pr.read());

            pw.close();
            pr.close();

            //InputStreamReader
            System.out.println("-----------InputStreamReader");
            fs = new FileInputStream("file1.txt");
            isr = new InputStreamReader(fs);

            while ((intVal = isr.read()) >= 0) {
                char charVal = (char) intVal;
                System.out.print(charVal);
            }
            isr.close();

            //OutputStreamWriter
            System.out.println("-----------OutputStreamWriter");
            outputstream1 = new FileOutputStream("file1.txt",true);
            osw = new OutputStreamWriter(outputstream1);
            message="OutputStreamWriter";
            osw.append(message);
            osw.close();

            //BuferedWriter generates newLine()
            System.out.println("-----------BufferedWriter");
            BufferedReader br = new BufferedReader(new FileReader("file1.txt"));
            BufferedWriter bw =  new BufferedWriter(new FileWriter("file1.txt",true));
            message="BufferedWriter";
            bw.write(message);

            while ((intVal = br.read()) >= 0) {
                char charVal = (char) intVal;
                System.out.print(charVal);
                bw.newLine();
            }
            bw.close();

            //BufferedReader readLine()
            System.out.println("-----------BufferedReader");
            while ((intVal = br.read()) >= 0) {
                char charVal = (char) intVal;
                System.out.print(br.readLine());
                System.out.print(charVal);
            }
            br.close();

            /*
            //Helper methods
            w = openWriter("file01.txt");
            w.write("Hello World");
            char[] charBuff = {'a','b','c'};
            Reader reader1 = openReader("file01.txt");
            while((intVal = reader1.read(charBuff)) >= 0) {
                for(int i=0; i < intVal; i++)
                    System.out.print(charBuff[i]);
            }
             */
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e){
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if (reader != null)
                    reader.close();
            }
            catch(IOException e2)
            {
                System.out.println(e2.getClass().getSimpleName() + " - " + e2.getMessage());
            }
        }
    }

    public static Reader openReader(String fileName) throws IOException {
        return Files.newBufferedReader(Paths.get(fileName));
    }

    public static Writer openWriter(String fileName) throws IOException {
        return Files.newBufferedWriter(Paths.get(fileName));
    }
}


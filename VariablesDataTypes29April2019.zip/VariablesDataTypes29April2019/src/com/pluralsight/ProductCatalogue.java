package com.pluralsight;

import com.pluralsight.Product;
import com.pluralsight.Supplier;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

public abstract class ProductCatalogue implements Iterator<Product>
{
    private Set<Product> productHashSet = new HashSet<>();
    public void isSupplied(Supplier s)
    {
        productHashSet.addAll(s.products());
    }

    public Iterator<Product> iterator()
    {
        return productHashSet.iterator();
    }

}

package com.pluralsight;

public class Worker implements Runnable{

    private BankAccount account;

    public Worker(BankAccount account) {
        this.account= account;
    }

    @Override
    public void run() {
        try {

            String strBank = null;
            for(int i=0; i< 10; i++) //Balance $10 added 10 times.
            {
                synchronized (account) {   //Synchronized statement Blocks - Allows Non-safe Thread class as safe way
                                           //Protects complex code
                    int startBalance= account.getBalance();
                    strBank = " Start Balance :" + startBalance;
                    account.deposit(10);
                    int endBalance= account.getBalance();
                    strBank = strBank + " End Balance :" + endBalance;
                    System.out.println(strBank + "\n");
                }
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}

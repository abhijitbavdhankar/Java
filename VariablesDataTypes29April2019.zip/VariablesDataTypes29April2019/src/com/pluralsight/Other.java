package com.pluralsight;

import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;

public class Other {

    static Logger logger = LogManager.getLogManager().getLogger(Logger.GLOBAL_LOGGER_NAME);

    //Precise Convenience Methods
    public void doWork()
    {
        logger.setLevel(Level.ALL);
        logger.entering("com.pluralsight.Other","doWork");
        logger.logp(Level.WARNING,"com.pluralsight.Other","doWork","Empty function");
        logger.exiting("com.pluralsight.Other","doWork");
    }

    //Precise Convenience Methods
    public void doWork(String left, String right)
    {
        logger.setLevel(Level.ALL);
        logger.entering("com.pluralsight.Other","doWork",new Object[]{left, right});
        //logger.logp(Level.WARNING,"com.pluralsight.Other","doWork","Empty function");
        String result = "<" + left + right + ">";
        System.out.println(result);
        logger.exiting("com.pluralsight.Other","doWork",result);
    }
}

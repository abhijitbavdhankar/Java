package com.pluralsight;

import java.util.ArrayList;
import java.util.List;

public class ArrayListString {

    public void ArrayListString() {
        List<String> numbers = new ArrayList<>();
        numbers.add(0, "1");
        numbers.add(1, "2");
        numbers.add(2, "3");

        for (String number : numbers) {
            System.out.println(number);
        }
    }

}

package com.pluralsight;

import java.lang.*;
import java.io.*;

public class BankAccount implements Serializable, Comparable{

    private String accountid;
    private int balance;
    private char lastTxType;
    private int lastTxAmount;
    private transient int totalBalance= 100; //transient means Do not serliaze this field
    private static final long serialVersionUID = 8294801185910209924L;

    /*

    java.io.InvalidClassException: com.pluralsight.BankAccount; local class incompatible:
    stream classdesc serialVersionUID = 8294801185910209924,
    local class serialVersionUID = 6407859077493824526
    */

    public BankAccount() {
    }

    public BankAccount(int balance) {
        this.balance = balance;
    }
    public BankAccount(String accountid, int balance) {
        this.accountid =  accountid;
        this.balance = balance;
    }
    public BankAccount(String accountid, int balance, char lastTxType,int lastTxAmount) {
        this.accountid =  accountid;
        this.balance = balance;
        this.lastTxType =  lastTxType;
        this.lastTxAmount = lastTxAmount;
    }

    //GET_SET
    public synchronized String getAccountid() {
        return accountid;
    }
    public synchronized void setAccountid(String accountid) {
        this.accountid = accountid;
    }

    public synchronized int getBalance() {
        return balance;
    }
    public synchronized void setBalance(int balance) {
        this.balance = balance;
    }

    //Fields added
    public synchronized char getlastTxType() {
        return lastTxType;
    }
    public synchronized void setlastTxType(char lastTxType) {
        this.lastTxType = lastTxType;
    }

    public synchronized int getlastTxAmount() {
        return lastTxAmount;
    }
    public synchronized void setlastTxAmount(int lastTxAmount) {
        this.lastTxAmount = lastTxAmount;
    }

    public synchronized void deposit(int amount) {
        this.balance += amount;
        this.lastTxType = 'd';
        this.lastTxAmount = amount;
    }
    public synchronized void withdrawal(int amount) {
        this.balance -= amount;
        this.lastTxType = 'w';
        this.lastTxAmount = amount;
    }

    //Custom Serilzation/DeSerialization when member is added to Class
    private void writeObject(ObjectOutputStream o) throws IOException
    {
        o.defaultWriteObject();
    }

    private void readObject(ObjectInputStream i) throws IOException, ClassNotFoundException
    {
        ObjectInputStream.GetField fields = i.readFields();
        this.accountid = (String) fields.get("accountid","1");
        this.balance = (int) fields.get("balance",0);
        this.lastTxType = (char) fields.get("lastTxType",'u');
        this.lastTxAmount = (int) fields.get("lastTxAmount",-1);
    }


    @Override
    public int compareTo(Object o) {
        BankAccount ba = (BankAccount) o;
        if(ba.getBalance() == 100)
            return this.balance; //1
        else
            return 0;
    }
}

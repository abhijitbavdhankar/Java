package com.pluralsight;
import java.lang.*;
import java.io.*;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public class ThreadCallableExample {

    String[] inputFiles = {"./ifile1.txt","./ifile01.txt"};
    //String[] outputFiles = {"./ofile1.txt","./ofile01.txt"};

    //Executors class
    public void ThreadingInputOutputFilesExecutorsClassCallable() throws IOException
    {
        ExecutorService es = null;

        try
        {
            es = Executors.newFixedThreadPool(2); //ExecutorService,Executors

            Future<Integer>[] results = new Future[inputFiles.length]; //Future<Integer>

            for(int i=0;i<=inputFiles.length;i++)
            {
                AdderCallable adder = new AdderCallable(inputFiles[i]);
                results[i] = es.submit(adder);

                //Callable callable = adder;//new AdderCallable(inputFiles[i]);
                //results[i] = es.submit(callable);
            }

            //Retrieving Adder class Results
            for(Future<Integer> result:results)
            {
                try {
                    int value = result.get(); //Blocks until return value is available
                    System.out.println("Total:" + value);
                }
                catch(ExecutionException ee) //Exception raised in AdderCallable class
                {
                    Throwable adderEx = ee.getCause(); //Get Adder exception
                    System.out.println(adderEx.getMessage());
                }
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }

        es.shutdown();
        //es.awaitTermination(60, TimeUnit.SECONDS);
    }
}

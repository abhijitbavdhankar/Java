package com.pluralsight;
import java.lang.*;
import java.io.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class ThreadingConcurrencyExample
{
    public static String[] inputFiles = {"ifile1.txt","ifile01.txt"};
    public static String[] outputFiles = {"ofile1.txt","ofile01.txt"};

    //MultipleThread
    public static void SingleThread() throws IOException
    {
        try
        {
            Adder adder=new Adder(inputFiles[0],outputFiles[0]);
            //adder.doAdd();
            Thread thread=new Thread(adder);
            thread.start();
            thread.join();
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    //MultipleThread
    public static void MultipleThread() throws IOException
    {
            try
            {
                for(int i=0;i<inputFiles.length;i++)
                {
                    Adder adder=new Adder(inputFiles[i],outputFiles[i]);
                    //adder.doAdd();
                    Thread thread=new Thread(adder);
                    thread.start();
                    thread.join();
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
    }

    //ThreadingArrays
    public static void ThreadingArrays() throws IOException
    {
        try
        {
            Thread[] ThreadArrays =  new Thread[inputFiles.length];

            for(int i=0;i<inputFiles.length;i++)
            {
                Adder adder=new Adder(inputFiles[i],outputFiles[i]);
                //adder.doAdd();
                ThreadArrays[i] = new Thread(adder);
                ThreadArrays[i].start();
            }

            for(Thread thread:ThreadArrays)
            {
                thread.join(); //Blocks waiting for thread completion
            }
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }

    /**
    ThreadPools
    Create queue for tasks
    Assign tasks into pool of threads
    Handles details of managing threads
    -------------------------------------------------------
    Thread Pool Types
    1.ExecutorsService interface
    Models thread pool behavior
    Can submit tasks
    Request and wait for pool shutdown
    2.Executors class
    Methods for creating thread pools
    Pools
    1.Dynamically sized pools
    2.Size limited pools
    3.Pools that schedule tasks for later
    -------------------------------------------------------
    MultiThreading - Relationship between Thread Tasks
    Caller may need results from worker thread
    May need to know if task succeeded

    Main Thread Launches Background Thread,
    1.Background Thread wants to send result back, Background Thread stores rsult in memory like object reference.
    2.Background Thread throws exception and Main thread wants to know about exception,
    Background Thread stores Exception Info in memory, Main Thread get Exception information from mmeory and carry on accordingly.
    3.Background Thread has result then Main Thread get result directly and carry on.
    4.Background Thread throws exception and pass exception information to Main thread, Main thread can have try-catch for exception and proceed accordingly.

    Java has 2 types for above.

    1.Callable Interface
    Represents a task to be run on a thread
    Can return results from Background Thread
    Can throw exceptions from Background Thread
    Member - call() method

    2.Future Interface
    Caller to harvest that results
    Represents results of a thread task - Returned by ExecutorsService.submit that can return future reference
    Member - get() method - Blocks until task completes
    Returns result back return back by Callable Interface
    Throws Exception if Callable Interface throws exception.
    */

    //Executors class
    public static void ThreadingExecutorsClass() //throws IOException
    {
        try
        {
            ExecutorService es = Executors.newFixedThreadPool(2); //ExecutorService,Executors

            for(int i=0;i<=inputFiles.length;i++)
            {
                Adder adder=new Adder(inputFiles[i],outputFiles[i]);
                //es.submit(adder);
                es.submit(adder);
            }

            es.shutdown();
            es.awaitTermination(60, TimeUnit.SECONDS);
        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }
}

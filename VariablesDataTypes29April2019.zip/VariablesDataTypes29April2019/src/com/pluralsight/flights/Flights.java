package com.pluralsight.flights;

public class Flights{

    //Access Modifiers
    public boolean bVar = true;

    private int passengers = 1, seats = 100;
    private int flightNumber, totalseatsbooked = 1, totalCheckedBags = 1, bags = 1;
    private int maxCarryOns = seats * 2, totalCarryOns = 1;
    private char flightClass = 'E';
    private String SFlightRoute = null;


    //Intialization Blocks
    private boolean[] seatsAvailable; //imp semi-colon
    {
        seatsAvailable = new boolean[seats];

        for(int i = 0; i < seats ; i++)
            seatsAvailable[i] = true;
    }

    // ----- CONSTRUCTOR ----------
    //public Flights()     {    }

    public Flights()
    {

    }

    public Flights(int passengers, int seats)
    {
        this(); //call Flights constructor
        this.passengers = passengers;
        this.seats = seats;
    }

    public Flights(int flightNumber)
    {
        this(); //call Flights constructor
        this.flightNumber = flightNumber;
    }

    public Flights(char flightClass)
    {
        this.flightClass = flightClass;
    }

    //Get-Accessor, Set-Mutator Properties

    public int getFlightNumber()
    {
        return flightNumber;
    }

    public void setFlightNumber(int flightNumber)
    {
        this.flightNumber = flightNumber;
    }


    public int getSeats()
    {
        //return seats;
        return 100;
    }

    public void setSeats(int seats)
    {
        this.seats = seats;
    }

    //---------Method overloading ------------------


    public void add1Passenger()
    {
        /*
        if( passengers <= 0)
            return;
        else if ( passengers < seats)
            passengers = passengers + 1;
        else
            FlightBooked();
        */

        if( FlightHasSeating() )
            passengers +=  1;
        else
            FlightBooked();

        return; //return can be reference to object/Arrays
    }

    public void add1Passenger(int bags)
    {
        if( FlightHasSeating() ) {
            add1Passenger(); // call above addPassenger method
            totalCheckedBags +=  bags;
        }
    }

    public void add1Passenger(Passengers p)
    {
           add1Passenger(p.getCheckedBags()); // call above addPassenger method
    }


    public void add1Passenger(int bags, int CarryOns)
    {
        if( FlightHasSeating() && FlightHasCarryOnSpace(CarryOns)) {
            //add1Passenger(bags()); // call above addPassenger bags method
            add1Passenger(bags);
            totalCarryOns +=  CarryOns;
        }
    }

    public void add1Passenger(Passengers p, int CarryOns)
    {
        if( FlightHasSeating() ) {
            add1Passenger(p.getCheckedBags(),CarryOns ); // call above addPassenger bags,CarryOns method
        }
    }
    /*
    public void add1Passenger(Passengers[] pList)
    {
        if( FlightHasSeating(pList.length) ) {
            passengers += pList.length;

            for(Passengers p : pList)
                totalCheckedBags += p.getCheckedBags();
        }
        else
            FlightBooked();
    }*/

    public void add1Passenger(Passengers... pList) //imp - varying number of parameters
    {
        if( FlightHasSeating(pList.length) ) {
            passengers += pList.length;

            for(Passengers p : pList)
                totalCheckedBags += p.getCheckedBags();
        }
        else
            FlightBooked();
    }

    public void addFlightRoute(String Sroute)
    {
        SFlightRoute = Sroute;
    }

    public boolean checkFlightHasSeats(Flights f2) //Check seats with Other Flight
    {
        totalseatsbooked = this.passengers + f2.passengers;
        /*
        if(totalseatsbooked <=  seats)
            return true;
        else
            return false; */

        System.out.println("checkFlightHasSeats:" + (totalseatsbooked <=  seats));

        return totalseatsbooked <=  seats;
    }

    public void printFlightDetails()
    {
        System.out.println("Number of seats:" + seats);
        System.out.println("Number of passengers:" + passengers);
        System.out.println("Flight Route:" + SFlightRoute);
        System.out.println("Flight Number:" + flightNumber);
        System.out.println("Flight Class:" + flightClass);
        System.out.println("Seats Available:" + (seats - totalseatsbooked));
        System.out.println("Seats Booked:" + totalseatsbooked);
        System.out.println("TotalCheckedBags:" + totalCheckedBags);
        System.out.println("MaxCarryOns:" + maxCarryOns);
        System.out.println("-----------------------------------");
    }

    private boolean FlightHasSeating()
    {
        //System.out.println("FlightHasSeating");
        //return passengers < seats;
        return passengers < getSeats();
    }

    private boolean FlightHasSeating(int passengerscount)
    {
        //System.out.println("FlightHasSeating");
        return passengers + passengerscount <= seats;
    }

    private boolean FlightHasCarryOnSpace(int carryOns)
    {
        //System.out.println("FlightHasCarryOnSpace");
        return totalCarryOns + carryOns <= maxCarryOns;
    }

    private void FlightBooked()
    {
        System.out.println("Flight booked");
    }

    public Flights createNewFlightWithBoth(Flights f2) //Create New Flight with Both Flights
    {
        Flights f3 =  new Flights();
        f3.seats = seats;
        f3.passengers = passengers + f2.passengers;
        System.out.println("-----New Flight Created with Both Flights----------");
        f3.addFlightRoute("NYtoLV");
        f3.printFlightDetails();
        return f3;
    }

    public void swap(Flights i, Flights j)
    {
        Flights temp = i;
        i = j;
        j = temp;
    }

    public void swapFlightNumbers(Flights i, Flights j)
    {
        int temp = i.getFlightNumber();
        i.setFlightNumber(j.getFlightNumber());
        j.setFlightNumber(temp);
    }

    @Override
    public boolean equals(Object o)
    {
        /*//JAVA CODE CRASH
        if(equals(o))
            return true; */

        if(super.equals(o)) //super treats object as instance of base class
            return true;    //use for accessing base class members that have been overridden

        if(!( o instanceof Flights))
            return false;

        Flights other = (Flights) o;
        return flightNumber == other.flightNumber && flightClass == other.flightClass;
    }
}


//final prevent from class inheriting and overriding
final class CargoFlights2 extends Flights{

    public void disp()
    {
        System.out.println("final class CargoFlights2");
    }
}

//abstract requires class inheriting and overriding
abstract class Pilot{

    //abstract requires method overriding
    abstract void FlightInTransit();

}
//abstract class inheriting
class PilotTraining extends Pilot{

    //abstract method overriding
    public void FlightInTransit()
    {
        System.out.println("Pilot Training");
    }
}




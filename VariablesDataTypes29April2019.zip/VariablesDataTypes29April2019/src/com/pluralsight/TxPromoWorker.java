package com.pluralsight;

public class TxPromoWorker extends TxWorker {

    protected BankAccount account;
    protected char txType; // ‘w’ -> withdrawal, ‘d’ -> deposit
    protected int amt;

    public TxPromoWorker(BankAccount account, char txType, int amt)
    {
        super(account,txType, amt);
        this.account = account;
        this.txType = txType;
        this.amt = amt;
        //run();
    }

    @Override
    public void run()
    {
        try {
                String strBank = "";
                //strBank = Objects.requireNonNull(strBank);
                int startBalance = 0;
                startBalance = account.getBalance();
                strBank = " TxPromoWorker Start Balance :" + startBalance;
                //System.out.println(txType);
                int bonus = 0;

                if (txType == 'w')
                    account.withdrawal(amt);
                else if (txType == 'd') {
                    synchronized (account) {
                        account.deposit(amt);
                        if (account.getBalance() > 500) { //Promotion Bank Gives 10% bonus on balance amt - Check negative bonus calculation is avoided
                            bonus = (int) ((account.getBalance() - 500) * 0.1);
                            account.deposit(bonus);
                            System.out.println(" Transaction:" + txType + " Bonus:" + bonus);
                            strBank = strBank + " Bonus:" + bonus;
                        }
                    }
                }

                strBank = strBank + " Transaction:" + txType;
                int endBalance = account.getBalance();
                strBank = strBank + " End Balance:" + account.getBalance();
                System.out.println(strBank + "\n");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}

package com.company;

import javax.swing.*;

public class VariableTypes {

    //VARIABLES DATA TYPES//
    int a1 = 1;
    short b1 = 1;
    long c1 = 10000L;
    byte flag1 = 70;
    float total=200;
    float total1 = 100.2f;
    double d1 = 19.07000001d;
    double e1 = Math.pow(19.07,-7); //EXPONENTIAL NUMBER
    double g1 = Math.pow(89.07,5);
    char j1 = 'A';
    char k1 = '\u00DA'; //4-DIGIT HEXADECIMAL NUMBER, default value '\u0000'
    boolean l1 = true; //default value is false
    int a2 = a1;
    float students = 30;
    float rooms = 4;
    int i = 0;

    private char charVar = 'A';
    private short sVar = 1;
    private long lVar = 10000L;
    private double lVar2 = 24901 * 1.6d;
    private double lVar3 = (double) (lVar2 * 1.6d);
    private byte byteflag = 0;

    static float fVartotal = 100.2f;
    static double dVar = 19.07000001d;

    public void swap(int i, int j)
    {
        System.out.println("Original values: " + i + "," + j);
        int temp = i;
        i = j;
        j = temp;
        System.out.println("Values after swap: " + i + "," + j);
    }

    public void OPERATORPRECEDENCE()
    {
        //-------------------
        float n1 = 12.0f;
        float p1 = 5.0f;

        float p12 = n1 * p1;
        float cd1 = n1 / p1;
        float cd12 = n1 % p1;

        a2 = ++a1;
        a2 = a1++;
        a2 = a1--;
        a2 = --a1;

        a2 += 2;
        a2 -= 1;
        a2 *= 5;
        a2 /= 7 * 1;

        float e119 = (n1 * p1) + (9 * (p1 + p12));
    }

    public void TYPECasting() {
        // TYPE Casting
        a2 = a1;
        a2 = (int) a1;
        short b2 = (short) b1;
        short b3 = (short) (b1 - b2);
        long c2 = (long) (c1  + b1);
    }

    public void CONDITIONALOPERATOR() {

        //CONDITIONAL OPERATOR ? :
        float studentsPerRoom = rooms == 0.0f ? 0.0f : students / rooms;
        System.out.println(studentsPerRoom);

        //if statement
        if (students == 'D')
            System.out.println("1");

        if (students > rooms)
            System.out.println("1");

        //if-else STATEMENT
        if (students > rooms)
            System.out.println("1");
        else
            System.out.println("01");

        //if-else if- else STATEMENT
        if (students > rooms)
            System.out.println("1");
        else if (students < rooms)
            System.out.println("01");
        else
            System.out.println("001");

        if (students > 1) { //NESTED - IF STATEMENT
            if (students > rooms)
                System.out.println(students / rooms);
        }

        if (students > 1 & students > rooms) //&
            System.out.println("1");

        if (students > 1 | students > rooms) //|
            System.out.println("1");

        if (!(total1 == 1)) //!
            System.out.println("01");

        if (students > 1 ^ students > rooms) //^
            System.out.println("1");

        if (students > 1 && students > rooms) //&&
            System.out.println("1");

        if (students > 1 || students > rooms) //||
            System.out.println("1");

        //SWITCH CASE STATEMENT
        int i = 18;
        switch (i % 2) {
            case 0:
                System.out.println("0");
                break;
            case 1:
                System.out.println("1");
                break;
            case 2:
                System.out.println("2");
                break;
            default:
                System.out.println("3");
                break;
        }
    }

    public void ARRAYS() {

        //ARRAYS
        char[] cArr = {'a', 'b', 'c', 'd'};
        double v1 = 1.0d, v2 = 1.0d, v3 = 1.0d;
        char c = 'd';
        double[] v4 = new double[cArr.length];

        if (c == 'a')
            v3 = v1 + v2;
        else if (c == 'b')
            v3 = v1 + v2 - flag1;
        else if (c == 'c')
            v3 = v1 + v2 * flag1;
        else if (c == 'd')
            v3 = v1 > v2 ? v1 + v2 / flag1 : 1.0d;
        else
            v3 = 1;

        float[] values = new float[5];
        values[0] = 1.0f;
        values[1] = 1.0f;
        values[2] = 1.0f;
        values[3] = 1.0f;
        values[4] = 1.0f;
        float sum = 0.0f;

        for (int i = 0; i < values.length; i++)
            sum += values[i];
        System.out.println(sum);

        float[] values1 = {0.0f, 1.0f, 1.0f, 1.0f, 1.0f};
        for (float i : values1) //IMP i variable use
        {
            sum += i;
            System.out.println(sum);
        }

        //Add,Sub,Multiply,Divide Arrays
        double[] v14 = {1.0d, 1.0d, 1.0d, 1.0d};
        double[] v5 = {1.0d, 1.0d, 1.0d, 1.0d};
        char c01 = 'a';
        double[] v15 = new double[v14.length];

        for (i = 0; i < v14.length; i++) {
            if (c == 'a')
                v15[i] = v14[i] + v5[i];
            else if (c == 's')
                v15[i] = v14[i] - v5[i];
            else if (c == 'm')
                v15[i] = v14[i] * v5[i];
            else if (c == 'd')
                v15[i] = v14[i] / v5[i];
            else if (c == 'e')
                v15[i] = v14[i] > v5[i] ? v14[i] + v5[i] / flag1 : 1.0d;
            else
                v15[i] = 1;
        }

        //2-D ARRAYS
        int[][] multi = new int[5][];
        multi[0] = new int[10];
        multi[1] = new int[10];
        multi[2] = new int[10];
        multi[3] = new int[10];
        multi[4] = new int[10];

        for (i = 0; i < 5; i++) {
            for (int j = 0; j < 10; j++) {
                multi[i][j] = 1;
                System.out.println("2DArr : multi[" + i + "]" + "[" + j + "]" + multi[i][j]);
            }
        }
    }
}

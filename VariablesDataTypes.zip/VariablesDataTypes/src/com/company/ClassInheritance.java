package com.company;

public class ClassInheritance {

    public String name = "ClassInheritance";

    public void dispShape(){
        System.out.println("-------- Class Inheritance --------------");
    }

}
//-------- Class Inheritance --------------
class Shape extends ClassInheritance{
    public String name = "Shape";

    public void dispShape(){
        System.out.println("Shape");
    }
}

class Square extends Shape{
    public String name = "Square";

    //--------Method overriding---------------
    public void dispShape(){
        System.out.println("Shape is Square");
    }
}

class Circle extends Shape {
    public String name = "Circle";

    public void dispShape(){
        System.out.println("Shape is Circle");
    }
}
// ------- MultiLevel Inheritance ---------------------
class Rectangle extends Circle {
    public String name = "Rectangle";

    //------Method overrloading-------------
    public void dispShape(int num){
        for(int i=0; i < num ; i++)
            System.out.println("Shape is Rectangle");
    }
}

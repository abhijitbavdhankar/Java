package com.company;

import com.company.*;
import com.company.flights.*;
import com.company.flights.Passengers;
import com.company.flights.CargoFlights;
import com.company.ClassInheritance;

/*
----------Single Type Import--------
import com.company.Flights;
import com.company.bar.Food;
import com.company.bar.Wine;

----------Import on demand----------
import com.company.Flights.*;
import com.company.bar.*;
*/

public class Main {

    public static void main(String[] args) {
        /* write your code here */

        //---------------  VARIABLES DATA TYPES ------------
        VariableTypes v = new VariableTypes();
        v.OPERATORPRECEDENCE();
        v.CONDITIONALOPERATOR();
        v.TYPECasting();
        v.ARRAYS();

        int num1 = 1;
        int num2 = 2;
        v.swap(num1, num2);

        //--------------- FibonacciSeries ------------
        FibonacciSeries f = new FibonacciSeries();
        f.FibonacciSeriesWhileLoop();
        f.FibonacciSeriesDoWhileLoop();
        f.FibonacciSeriesForLoop();

        //---------- Air Flight -----------------------
        Flights f1 = new Flights(10);
        String sroute = "NYToSF";
        f1.addFlightRoute(sroute);
        f1.add1Passenger();
        f1.printFlightDetails();

        Flights f11 = new Flights(11);
        sroute = "NYToLA";
        f11.addFlightRoute(sroute);
        f11 = f1;
        f11.printFlightDetails();

        f1.add1Passenger();
        f1.add1Passenger();
        f1.printFlightDetails();

        Flights f2 = new Flights(11);
        sroute = "NYToMN";
        f2.addFlightRoute(sroute);
        f2.add1Passenger();
        f2.add1Passenger();
        f2.printFlightDetails();

        //Flight Combined
        Flights f3 = null;

        if(f1.checkFlightHasSeats(f2))  //Flights f3 =  new Flights();
            f1.createNewFlightWithBoth(f2);

        if(f3!=null)
            System.out.println("Flight Combined");

        //Add Passengers to Flights
        Passengers p1 = new Passengers(1);
        Passengers p2 = new Passengers(1,3);
        Passengers p3 = new Passengers(0,1);
        Passengers p4 = new Passengers(0,2);

        f1.add1Passenger();;
        f1.add1Passenger(2);
        f1.add1Passenger(p1);
        f1.add1Passenger(1,1);
        f1.add1Passenger(p2, 1);

        short Bags = 2;
        f1.add1Passenger(Bags, 2);; //call int bags, int carryons

        //Flights Swapped
        System.out.println("------------Original Flights values: ---------------");
        f1.printFlightDetails();
        f2.printFlightDetails();

        f1.swap(f1,f2);

        System.out.println("--------Values after Flights swap: ---------------");
        f1.printFlightDetails();
        f2.printFlightDetails();

        System.out.println("--------Values after Flights Numbers swap: ---------------");
        f1.swapFlightNumbers(f1,f2);
        System.out.println(f1.getFlightNumber());
        System.out.println(f2.getFlightNumber());

        f1.add1Passenger((new Passengers[] { p3, p4 } ));
        f1.add1Passenger(p3, p4);

        //CargoFlighhts
        CargoFlights cf =  new CargoFlights();
        cf.add1Package(1.0 ,2.0, 3.6);
        cf.add1Passenger(p1);

        Flights f4 = new CargoFlights();  //can be assigned to base class typed references
        f4.add1Passenger(p2);

        Flights[] squadron = new Flights[5];
        squadron[0] = new Flights();
        squadron[1] = new CargoFlights();
        squadron[2] = new Flights();
        squadron[3] = new CargoFlights();
        squadron[4] = new CargoFlights();

        Flights f5 = new Flights();
        System.out.println("Seats are: " + f5.getSeats());
        CargoFlights cf2 =  new CargoFlights();
        System.out.println("Seats are: " + cf2.getSeats());
        Flights f6 = new CargoFlights();
        System.out.println("Seats are: " + f6.getSeats());

        Object[] stuff = new Object[3];
        stuff[0] = new Flights();
        stuff[1] = new Passengers(0,2);
        stuff[2] = new CargoFlights();
        Object obj = new Passengers(0,2);;
        obj =  new Flights[5];
        obj = new CargoFlights();
        CargoFlights cf3 = (CargoFlights) obj;

        if( obj instanceof CargoFlights) {
            cf3.add1Passenger(p1);
            cf3.add1Package(1.0, 2.0, 4.0);
            //System.out.println("Seats are: " + obj.getSeats());
        }

        CargoFlights cf4 = cf3;
        if( cf4.equals(cf3) )
            System.out.println("Equal Flights");

        if( f1.equals(p1) )
            System.out.println("Equal Flights");
        else
            System.out.println("Not Equal Flights");

        /*----------PACKAGES-----------------------------------------------------------
        Package name is part of the Type name
        Class is part of Package name
        Package is part of Class name
        Reverse domain naming

        Type name is qualified by Package name
        There is a class com.company.Flights
        */

        com.company.flights.Flights packageClass = new com.company.flights.Flights(14);
        packageClass.getSeats();

        /*
        Fully qualified our all type names
        Compiler needs to know each type's package
        Explicitly qualifying each type is impractical
        Hard to read and time-consuming
        Java offers Alternatives to Explicitly qualifying types
        Use simple type's name
        1.Types in current package do not need to be qualified
        2.Types in java.lang do not need to be qualified
        Example - Object, String, StringBuilder, primitive wrapper classes
        3.Type imports - guide compiler to map simple names to qualified names

        Type Imports
        1.Single Type Import
        Provides mapping for a single type
        import com.company.Flights;
        Automaticaaly by IDE
        Third party pacakage
        Example package.com.company.bar;

        import com.company.bar -  Food and Wine class;
        import com.company.Flights.Food;
        import com.company.Flights.Accessory;

        Food fn -  new Food();
        Accessory a = new Accessory();

        2.Import on demand
        Provides mapping for all types in a package

        import com.company.*
        import com.company.Flights.

         --------------------------------------------------
         ARCHIVE FILES = JAR FILES, COMPRESSING FILES, MANIFEST(NAME, VALUE) PAIRS -  REGARDING ARCHIVE CONTENT
         */



        //---------- Class Inheritance  -----------------------
        ClassInheritance c = new ClassInheritance();
        c.dispShape();
        Shape s = new Shape();
        s.dispShape();
        Square sq = new Square();
        sq.dispShape();
        Circle ci = new Circle();
        ci.dispShape();
        Rectangle rt =  new Rectangle();
        rt.dispShape(5);

        //---------- Polymorphism -----------------------
        Bank b;
        b = new SBIBank();
        System.out.println("--------SBIBank Rate of Interest: "+b.getRateOfInterest(10000.00, 0.07));
        b = new ICICIBank();
        System.out.println("--------ICICIBank Rate of Interest: "+b.getRateOfInterest(10000.00, 0.08));
        b = new AXISBank();
        System.out.println("--------AXISBank Rate of Interest: "+b.getRateOfInterest(10000.00,0.09));

        //-------------Object Array---------------
        MathEquations[] m = new MathEquations[4];
        m[0] = create(1,2,'a');
        m[1] = create(1,2,'s');
        m[2] = new MathEquations('m',1,2);
        m[3] = new MathEquations('d',1,2);

        for(MathEquations n : m)
        {
            n.execute();
            System.out.println("Result is: " + n.getResult());
        }

        double leftVal = 9.0d;
        double rightVal = 2.0d;
        int leftInt = 9;
        int rightInt = 2;

        MathEquations m1 = new MathEquations('d');
        m1.execute(leftVal, rightVal);
        System.out.println("Result is: " + m1.getResult());
        m1.execute(leftInt, rightInt);
        System.out.println("Integer Result is: " + m1.getResult());
        m1.execute((double)leftInt, rightInt);
        System.out.println("Integer Result is: " + m1.getResult());

        //----------- InputOutputStreamsFiles -----------------------------------------
        InputOutputStreamsFiles i = new InputOutputStreamsFiles();
        i.InputOutputStreamsFilesExample();
    }

    public static MathEquations create(double leftVal, double rightVal,char oprCode)
    {
        MathEquations m = new MathEquations();
        m.setleftVal(leftVal);
        m.setrightVal(rightVal);
        m.setoprCode(oprCode);
        return m;
    }

}

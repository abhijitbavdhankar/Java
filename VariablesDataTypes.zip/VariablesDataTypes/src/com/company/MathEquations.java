package com.company;

public class MathEquations {

    public double leftVal;
    public double rightVal;
    public char oprCode;
    public double result;

    // ----- CONSTRUCTOR ----------
    public MathEquations()    {            }
    public MathEquations(char oprCode)    {        this.oprCode = oprCode;    }
    public MathEquations(char oprCode, double leftVal, double rightVal)
    {
        this(oprCode);
        this.leftVal = leftVal;
        this.rightVal = rightVal;
    }

    //Get-Accessor, Set-Mutator Properties
    public double getleftVal()    {        return leftVal;    }
    public void setleftVal(double sealeftValts)    {        this.leftVal = leftVal;    }
    public double getrightVal()    {        return rightVal;    }
    public void setrightVal(double rightVal)    {        this.rightVal = rightVal;    }
    public char getoprCode()    {        return oprCode;    }
    public void setoprCode(char oprCode)    {        this.oprCode = oprCode;    }

    public double getResult(){ return result; }

    public void execute(double leftVal, double rightVal) {
        this.leftVal = leftVal;
        this.rightVal = rightVal;

        execute();
    }

    public void execute(int leftVal, int rightVal) {
        this.leftVal = leftVal;
        this.rightVal = rightVal;

        execute();

        result = (int) result;
    }

    public void execute()
    {
        switch (oprCode) {
            case 'a':
                result = rightVal + leftVal;
                System.out.println("add");
                break;
            case 's':
                result = rightVal - leftVal;
                System.out.println("subtract");
                break;
            case 'm':
                result = rightVal * leftVal;
                System.out.println("multiply");
                break;
            case 'd':
                result = rightVal / leftVal;
                System.out.println("divide");
                break;
            default:
                System.out.println("InValid Oprcode");
                result =  0.0d;
                break;
        }
    }
}

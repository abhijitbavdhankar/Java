package com.company;

public class Polymorphism {
    public String name = "Polymorphism";
    public double amount, interest, premium, sum;

    public void disp(){
        System.out.println("-------- Polymorphism -------");
    }
}

//---------------Polymorphism----------------
class Bank extends Polymorphism{

    public double getRateOfInterest(double amount, double interest)
    {
        sum = amount - (interest * 12);
        System.out.println("---------Bank-----------------");

        for(int i=0; i <12 ; i++)
        {
            premium = amount - (interest * i * 0.01);
            System.out.println("Premium Amount for " + (i+1) + " month is:" + premium);
    }

        return sum;
    }
}

class SBIBank extends Bank{

    public double getRateOfInterest(double amount, double interest)
    {
        sum = amount - (interest * 12);
        System.out.println("---------SBIBank-----------------");

        for(int i=0; i <12 ; i++)
        {
            premium = amount - (interest * i * 0.02);
            System.out.println("Premium Amount for " + (i+1) + " month is:" + premium);
        }

        return sum;
    }
}

class ICICIBank extends Bank{

    public double getRateOfInterest(double amount, double interest)
    {
        sum = amount - (interest * 12);
        System.out.println("---------ICICIBank-----------------");

        for(int i=0; i <12 ; i++)
        {
            premium = amount - (interest * i * 0.04);
            System.out.println("Premium Amount for " + (i+1) + " month is:" + premium);
        }

        return sum;
    }
}

class AXISBank extends Bank{

    public double getRateOfInterest(double amount, double interest)
    {
        sum = amount - (interest * 12);
        System.out.println("---------AXISBank-----------------");

        for(int i=0; i <12 ; i++)
        {
            premium = amount - (interest * i * 0.09);
            System.out.println("Premium Amount for " + (i+1) + " month is:" + premium);
        }

        return sum;
    }
}


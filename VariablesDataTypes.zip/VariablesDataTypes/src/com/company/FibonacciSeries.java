package com.company;

import javax.swing.*;

public class FibonacciSeries {

    public int num = 7;
    public int fibo = 1;

    public void FibonacciSeriesWhileLoop()
    {
        while ( num > 1)
        {
            fibo *= num;
            num -= 1;
        }
        System.out.println("Num is: " + num + " Fibo: " + fibo);
    }

    public void FibonacciSeriesDoWhileLoop()
    {
        do {
            fibo *= num;
            num -= 1;
        } while(num > 1);

        System.out.println("Num is: " + num + " Fibo: " + fibo);
    }

    public void FibonacciSeriesForLoop()
    {
        for(int i = 1; i <= num ; i++)
        {
            fibo *= num;
            num--;
        }

        System.out.println("Num is: " + num + " Fibo: " + fibo);
    }
}

package com.company.flights;

public class Passengers {

    private int freeBags;
    private int checkedBags;
    private double perBagFee;

    // ----- CONSTRUCTOR ----------
    public Passengers()     {    }
    public Passengers(int freeBags)
    {
        this(freeBags > 1 ? 25.0d : 15.0d); // imp call perBagfRee constructor
        this.freeBags = freeBags;
    }

    public Passengers(int checkedBags, int freeBags)
    {
        this(freeBags); //imp call above freeBags constructor
        this.checkedBags = checkedBags;
    }

    private Passengers(double perBagFee)
    {
        this.perBagFee = perBagFee;
    }

    //Get-Accessor, Set-Mutator Properties
    public int getCheckedBags()
    {
        return checkedBags;
    }

    public void setCheckedBags(int checkedBags)
    {
        this.checkedBags = checkedBags;
    }
}

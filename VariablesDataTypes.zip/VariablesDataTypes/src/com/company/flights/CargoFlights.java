package com.company.flights;

public class CargoFlights extends Flights{

    int passengers = 1, seats = 15;
    float maxCargoSpace = 1000.0f;
    float usedCargoSpace;

    public void FlightInTransit()
    {
        System.out.println("Flight In Transit");
    }

    @Override
    public int getSeats()
    {
        //return seats;
        return 15;
    }

    public void setSeats(int seats)
    {
        this.seats = seats;
    }

    //final prevent method from inheriting and overriding
    public final void add1Package(double height, double width, double depth)
    {
        double size = height * width * depth;

        if(hasCargo(size))
            usedCargoSpace += size;
        else
            handleNoSpace();
    }

    private boolean hasCargo(double size)
    {
        return usedCargoSpace + size <= maxCargoSpace;
    }

    private void handleNoSpace()
    {
        System.out.println("Not enough space");
    }

}

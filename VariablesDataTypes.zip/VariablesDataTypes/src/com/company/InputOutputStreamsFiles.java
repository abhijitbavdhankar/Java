package com.company;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.CharArrayReader;
import java.io.CharArrayWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.PipedInputStream;
import java.io.PipedOutputStream;
import java.io.PipedReader;
import java.io.PipedWriter;
import java.io.Reader;
import java.io.StringReader;
import java.io.StringWriter;
import java.io.Writer;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.nio.file.FileSystem;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.io.ByteArrayInputStream;
import java.util.Random;

public class InputOutputStreamsFiles {

    public void InputOutputStreamsFilesExample()  {

        Writer w = null;
        Reader reader = null;

        try {

            //char[] buff - FileWriter, Writer
            FileWriter fw = new FileWriter("C://Users//file1.txt");
            fw.write("Welcome Java.");

            w = new FileWriter("C://Users//file1.txt");
            char charA = 'a';
            w.write(charA);
            char[] charBuff = {'a','b','c'};
            w.write(charBuff);
            String str = "Hi Java";
            w.write(str);

            reader = new FileReader("C://Users//file1.txt");
            int data = reader.read();
            while (data != -1) {
                System.out.print((char) data);
            }

            int intVal;
            while ((intVal = reader.read()) >= 0) {
                char charVal = (char) intVal;
                System.out.print(charVal);
            }

            charBuff = new char[9];
            int length=0;
            while ((length = reader.read(charBuff)) >= 0 ) {
                for(int i=0; i < length; i++) {
                    char charVal = charBuff[i];
                    System.out.print((char) data);
                }
            }

            //InputStream - Reading one byte at a time
            InputStream inputstream = new FileInputStream("C://Users//file1.txt");
            data = inputstream.read();
            while (data != -1) {
                data = inputstream.read();
                System.out.print(data);
            }
            while ((intVal = inputstream.read()) >= 0) {
                byte byteVal = (byte) intVal;
                System.out.print((char) byteVal);
            }
            inputstream.close();

            OutputStream outputstream = new FileOutputStream("C://Users//file1.txt");
            String content = "Hello Java";
            byte[] bytes = content.getBytes();
            outputstream.write(bytes);
            byte byteVal = 100;
            outputstream.write(byteVal);
            byte[] bytesArr = {1,2,3,4,5,6,7,8,9};
            outputstream.write(bytesArr);

            //ByteArrayInputStream class allows a buffer in the memory to be used as an InputStream.
            //The input source is a byte array.
            String message = "Welcome Java";
            ByteArrayInputStream strByteArrayInputStream = new ByteArrayInputStream(message.getBytes());
            int ch;
            while ( (ch = strByteArrayInputStream.read()) != -1) {
                System.out.println("Your capitalized message: " + (char) ch);
            }

            ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(9);
            byteArrayOutputStream.write(bytesArr);

            //PipedInputStream
            PipedInputStream pipedInputStream = new PipedInputStream();
            PipedOutputStream pipedOutputStream = new PipedOutputStream();
            pipedInputStream.connect(pipedOutputStream);
            pipedOutputStream.write(bytesArr);
            pipedOutputStream.write(byteVal);

            for(int i=0; i <=1 ; i++ )
                System.out.println((char) pipedInputStream.read());

            //CharArrayWriter
            CharArrayWriter charArrayWriter = new CharArrayWriter();
            charArrayWriter.write(message);

            CharArrayReader charArrayReader = new CharArrayReader(charBuff);
            intVal = 0;
            while ((intVal = charArrayReader.read()) >= 0) {
                char charVal = (char) intVal;
                System.out.print(charVal);
            }

            //StringWriter
            StringWriter sw = new StringWriter();
            sw.write(message);

            StringReader sr = new StringReader(message);
            System.out.println(sr.read());

            //PipedWriter
            PipedWriter pw = new PipedWriter();
            PipedReader pr = new PipedReader();
            pw.write(charBuff);
            pw.connect(pr);

            for(int i=0; i <=1 ; i++ )
                System.out.println((char) pr.read());

            //InputStreamReader
            FileInputStream fs = new FileInputStream("C//Users//file1.txt");
            InputStreamReader is = new InputStreamReader(fs);

            while ((intVal = is.read()) >= 0) {
                char charVal = (char) intVal;
                System.out.print(charVal);
            }

            //OutputStreamWriter
            OutputStream outputstream1 = new FileOutputStream("C://Users//file1.txt");
            OutputStreamWriter ios = new OutputStreamWriter(outputstream1);
            ios.write(message);

            //BufferedReader readLine()
            BufferedReader br = new BufferedReader(new FileReader("C://Users//file1.txt"));
            while ((intVal = br.read()) >= 0) {
                char charVal = (char) intVal;
                System.out.print(br.readLine());
                System.out.print(charVal);
            }

            //BuferedWriter generates newLine()
            BufferedWriter bw =  new BufferedWriter(new FileWriter("C://Users//file1.txt"));
            bw.write(message);
            while ((intVal = br.read()) >= 0) {
                char charVal = (char) intVal;
                System.out.print(charVal);
                bw.newLine();
            }

            w = openWriter("file1.txt");
            w.write("Hello World");

            reader = openReader("file1.txt");
            while((length = reader.read(charBuff)) >= 0) {
                for(int i=0; i < length; i++)
                    System.out.print(charBuff[i]);
            }

            fw.close();
        }
        catch (FileNotFoundException e){
            e.printStackTrace();
        }
        catch (IOException e){
            e.printStackTrace();
        }
        finally
        {
            try
            {
                if (reader != null)
                    reader.close();
            }
            catch(IOException e2)
            {
                System.out.println(e2.getClass().getSimpleName() + " - " + e2.getMessage());
            }
        }
    }

    public static Reader openReader(String fileName) throws IOException {
        return Files.newBufferedReader(Paths.get(fileName));
    }

    public static Writer openWriter(String fileName) throws IOException {
        return Files.newBufferedWriter(Paths.get(fileName));
    }
}


package com.mantiso.models;

public class Student {
	
	public String id;
	public String firstName;
	public String lastName;
	
	 // constructors, getters and setters goes here
	
	public Student(String i, String string, String string2) {
		id = i;
		firstName = string;
		lastName = string2;
		// TODO Auto-generated constructor stub
	}
	
	public String getId()
	{
		return id;
	}
	
	public void setId(String value){
        this.id = value;
    }
	
	public String getFirstName()
	{
		return firstName;
	}
	
	public void setFirstName(String firstName){
        this.firstName = firstName;
    }
	
	public String getLastName()
	{
		return lastName;
	}
	
	public void setLastName(String lastName){
        this.lastName = lastName;
    }

}

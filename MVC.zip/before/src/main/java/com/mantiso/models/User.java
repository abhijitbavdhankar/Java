package com.mantiso.models;

import java.io.Serializable;

public class User implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String _name;
    private String _email;
    
    public User(String _name, String _email){
		this._name = _name;
		this._email = _email;
	}
 

    public String getName(){
        return _name;
    }

    public void setName(String value){
        this._name = value;
    }

    public String getEmail(){
        return _email;
    }

    public void setEmail(String value){
        this._email = value;
    }
}

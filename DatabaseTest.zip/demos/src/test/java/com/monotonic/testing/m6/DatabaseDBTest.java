package com.monotonic.testing.m6;
import org.junit.Test;
import java.sql.*;
import javax.sql.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;
/**
 * Created by abhijit on 05-07-2018.
 */
public class DatabaseDBTest {

    @Test
    public void shouldLoadSampleData()
    {
        try {
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            Connection conn = DriverManager.getConnection("jdbc:sqlserver://DELL\\CMC;DatabaseName=PERTRAC","sa", "sa");
            //Connection conn = DriverManager.getConnection("jdbc:sqlserver://DELL\\CMC;DatabaseName=PERTRAC;integratedSecurity=true;");
            DriverManager.setLoginTimeout(100);
            Statement stmt = conn.createStatement();
            stmt = conn.createStatement();
            stmt.setQueryTimeout(100);
            //ResultSet resultSet = stmt.executeQuery("SELECT TOP 1 ID FROM [dbo].[PerTracID]");
            ResultSet resultSet = stmt.executeQuery("SELECT TOP 1000 [ID],[Data]\n" +
                    "\n  FROM [PERTRAC].[dbo].[PerTracID] \n" +
                    "\n  ORDER BY [ID]");

            while (resultSet.next())  {
                String ID = resultSet.getString("ID");
                String Data = resultSet.getString("Data");
                System.out.println("ID : " + ID);
                System.out.println("Data : " + Data);
                //resultSet.next();
            }

            executeSprocGetInParams(conn,1);
            //executeSprocInsertInParams(conn,"ABN AMRO");
            executeSprocUpdateInParams(conn, 1, "\\\\invnysql1\\Pertrac\\Universe\\Bmarks.unv");
            //executeSprocDelInParams(conn, 1, "2003-07-31 00:00:00.000");

            conn.close();
        }
        catch (ClassNotFoundException cnfe) {
            System.err.println(cnfe.getMessage());
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    public static void executeSprocGetInParams(Connection conn, int ID) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("{call [dbo].[DM_GET_PERFORMANCE_COUNT](?)}");
            pstmt.setInt(1, ID);
            ResultSet resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                System.out.println("------------------------------------------");
                System.out.println("DM_GET_PERFORMANCE_COUNT \t: " + resultSet.getString("DM_GET_PERFORMANCE_COUNT"));
            }
            resultSet.close();
            pstmt.close();

        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    public static void executeSprocInsertInParams(Connection conn, String strMasterName) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("{call [dbo].[DM_INS_MNAME](?,?)}");
            pstmt.setString(1, strMasterName);
            pstmt.setInt(2, Types.INTEGER);
            ResultSet resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                System.out.println("------------------------------------------");
                System.out.println("DM_INS_MNAME");
                String ID = resultSet.getString("ID");
                System.out.println("ID : " + ID);
            }
            resultSet.close();
            pstmt.close();
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    public static void executeSprocUpdateInParams(Connection conn, int ID, String str) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("{call [dbo].[DM_UPD_BENCHMARKS](?,?)}");
            pstmt.setInt(1, ID);
            pstmt.setString(2, str);
            ResultSet resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                System.out.println("------------------------------------------");
                System.out.println("DM_UPD_BENCHMARKS");
            }
            resultSet.close();
            pstmt.close();
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }

    public static void executeSprocDelInParams(Connection conn, int ID, String str) {
        try {
            PreparedStatement pstmt = conn.prepareStatement("{call [dbo].[DM_DEL_PERFORMANCE](?,?)}");
            pstmt.setInt(1, ID);
            pstmt.setString(2, str);
            ResultSet resultSet = pstmt.executeQuery();

            while (resultSet.next()) {
                System.out.println("------------------------------------------");
                System.out.println("DM_DEL_PERFORMANCE");
            }
            resultSet.close();
            pstmt.close();
        }
        catch (SQLException e) {
            System.err.println(e.getMessage());
        }
    }
}

package com.monotonic.testing.m5;

/**
 * Created by abhijit on 07-06-2018.
 */
import java.util.List;

import com.monotonic.testing.m5.SalesOrderException;
import com.monotonic.testing.m5.OrderSummary;

public interface OrderService {

    List<OrderSummary> getOrderSummary(long customerId) throws SalesOrderException;
}

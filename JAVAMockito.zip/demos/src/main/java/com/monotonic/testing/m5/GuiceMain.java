package com.monotonic.testing.m5;

import com.monotonic.testing.m5.before_refactor.ReportRunner;
import com.monotonic.testing.m5.after_refactor.SimpleReportRunner;
import com.monotonic.testing.m5.guice.GuiceSalesReportRunner;
import com.monotonic.testing.m5.spring_xml.SpringXmlSalesReportRunner;

/**
 * Created by abhijit on 30-05-2018.
 */
public class GuiceMain {

    public static void main(String[] args){
        String fileLocation[] = new String[1];
        fileLocation[0]="E:\\Abhijit\\Office\\JAVA\\CODE\\PLURALSIGHT\\java-testing-introduction\\05\\demos\\src\\main\\resources\\example-sales.csv";
        ReportRunner r = new ReportRunner();
        r.main(fileLocation);
        System.out.println("SimpleReportRunner");
        SimpleReportRunner sr = new SimpleReportRunner();
        sr.main(fileLocation);
        System.out.println("SpringXmlSalesReportRunner");
        SpringXmlSalesReportRunner spring = new SpringXmlSalesReportRunner();
        spring.main(fileLocation);
        System.out.println("GuiceSalesReportRunner");
        GuiceSalesReportRunner guice = new GuiceSalesReportRunner();
        guice.main(fileLocation);
    }
}

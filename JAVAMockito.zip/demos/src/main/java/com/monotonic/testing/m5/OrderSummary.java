package com.monotonic.testing.m5;
import java.math.BigDecimal;
/**
 * Created by abhijit on 07-06-2018.
 */
public class OrderSummary {
    private String orderNumber;
    private int itemCount;
    private BigDecimal totalAmount;

    public String getOrderNumber() {
        return orderNumber;
    }

    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    public int getItemCount() {
        return itemCount;
    }

    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }
}

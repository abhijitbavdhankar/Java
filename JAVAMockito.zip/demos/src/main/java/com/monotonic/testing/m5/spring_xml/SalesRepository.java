package com.monotonic.testing.m5.spring_xml;

import java.util.List;

public interface SalesRepository {

    public List<Sale> loadSales();

}

package com.pluralsight.getorganized;
import org.junit.Test;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasKey;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.assertTrue;

/**
 * Created by abhijit on 28-05-2018.
 */
public class HamcrestExampleTest {

    private List<Integer> getNumbers()
    {
        return Arrays.asList(1,2,3,4,5);
    }

    public Map<String, Integer> getValues()
    {
        final HashMap<String, Integer> map = new HashMap<>();
        map.put("A",1);
        map.put("B",2);
        return map;
    }

    @Test
    public void mapShouldContainValue()
    {
        Map<String, Integer> values = getValues();

        assertThat(values, hasKey("B"));
        //assertTrue(values.containsKey("B"));
    }

    @Test
    public void listOrderingIsIrrelevant()
    {
        List<Integer> numbers = getNumbers();
        assertThat(numbers, hasItem(5));
    }
}

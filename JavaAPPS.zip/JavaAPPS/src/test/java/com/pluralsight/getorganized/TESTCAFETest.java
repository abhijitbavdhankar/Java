package com.pluralsight.getorganized;
import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import org.junit.Before;
import org.junit.After;
import static com.pluralsight.getorganized.TESTCOFFEETYPE.Espresso;
import static com.pluralsight.getorganized.TESTCOFFEETYPE.Latte;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.junit.Assert.assertThat;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.hasProperty;

/**
 * Created by abhijit on 28-05-2018. TDD(TEST DRIVEN DEVELOPMENT)
 */

public class TESTCAFETest {

    public static final int ESPRESSO_B = Espresso.getRequiredBeans();
    public static final int NO_MILK = 0;
    public static final int NO_BEANS = 0;

    private TESTCAFE cafe;
    //@Before - Before each method test runs
    //@After  - After each method test runs
    //@BeforeClass - Before all tests in the class
    //@AfterClass - After all tests in the class
    public TESTCAFETest(){
        System.out.println("Constructor");
    }

    @BeforeClass
    public static void beforeClass() {
        System.out.println("before class");
    }
    @AfterClass
    public static void afterClass() {
        System.out.println("after class");
    }
    @Before
    public void before() {
        cafe = new TESTCAFE();
        System.out.println("before");
    }
    @After
    public void after() {
        System.out.println("after");
    }

    /*private TESTCAFE withBeans() { //REFACTOR EXTRACT METHOD
        TESTCAFE cafe = new TESTCAFE();
        cafe.restockBeans(7);
        return cafe;
    }*/

    private void withBeans()
    {
        cafe.restockBeans(ESPRESSO_B);
    }

    @Test
    public void canBrew() {
        System.out.println("Derived class");
    }

    @Test
    public void canBrewEspresso() {
        // given
        //TESTCAFE cafe = new TESTCAFE();
        //cafe.restockBeans(7);
        //TESTCAFE cafe = withBeans();
        withBeans();
        // when
        TESTCOFFEE coffee = cafe.brew(Espresso);
        // then
        //assertEquals("Wrong number of beans",7, coffee.getBeans());
        //assertEquals("Wrong amount of milk",0, coffee.getMilk());
        assertEquals("Wrong coffee type",Espresso, coffee.getType());
        //assertEquals("Wrong number of beans",Espresso.getRequiredBeans(), coffee.getBeans());
        assertEquals("Wrong number of beans",ESPRESSO_B, coffee.getBeans());
        assertEquals("Wrong amount of milk", NO_MILK, coffee.getMilk());
    }

    @Test
    public void brewingEspressoConsumesBeans() {
        // given
        //TESTCAFE cafe = withBeans();
        withBeans();
        // when
        cafe.brew(Espresso);
        // then
        //assertEquals(0, cafe.getBeansInStock());
        assertEquals(NO_BEANS, cafe.getBeansInStock());
    }

    @Test
    public void canBrewLatte() {
        // given
        //TESTCAFE cafe = withBeans();
        //cafe.restockMilk(227);
        withBeans();
        cafe.restockMilk(Latte.getRequiredMilk());
        // when
        TESTCOFFEE coffee = cafe.brew(Latte);
        // then
        //assertTrue(Latte == coffee.getType());
        assertEquals("Wrong coffe type",Latte, coffee.getType());
    }

    @Test(expected=IllegalArgumentException.class)
    public void mustRestockMilk() {
        // given
        TESTCAFE cafe = new TESTCAFE();
        // when
        //cafe.restockMilk(0);
        cafe.restockMilk(NO_MILK);
    }

    @Test(expected = IllegalArgumentException.class)
    public void mustRestockBeans() {
        // given
        TESTCAFE cafe = new TESTCAFE();
        // when
        cafe.restockBeans(NO_BEANS);
    }

    @Test(expected = IllegalStateException.class)
    public void lattesRequireMilk() {
        // given
        //TESTCAFE cafe = withBeans();
        withBeans();
        // when
        cafe.brew(Latte);
    }
}

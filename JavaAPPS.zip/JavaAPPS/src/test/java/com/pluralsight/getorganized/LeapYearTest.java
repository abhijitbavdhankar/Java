package com.pluralsight.getorganized;
import org.junit.Test;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
/**
 * Created by abhijit on 28-05-2018.
 */
public class LeapYearTest {

    // a year is a leap year if it is divisible by four
    // but, years divisible by 100, are not leap years,
    // except years divisible by 400

    @Test
    public void leapYearsAreDivisibleByFour() {
        assertTrue(LeapYear.isLeap(4016));
    }

    @Test
    public void normalYearIsNotDivisibleByFour() {
        assertFalse(LeapYear.isLeap(5));
    }

    @Test
    public void yearsDivisibleBy100AreNotLeapYears() {
        assertFalse(LeapYear.isLeap(3800));
    }

    @Test
    public void yearsDivisibleBy400AreLeapYears() {
        assertTrue(LeapYear.isLeap(4000));
    }
}

package com.pluralsight.getorganized.spring_xml;

import java.util.List;

public interface SalesRepository {

    public List<Sale> loadSales();

}

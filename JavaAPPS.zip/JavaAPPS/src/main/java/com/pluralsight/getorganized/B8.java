package com.pluralsight.getorganized;

/**
 * Created by abhijit on 27-05-2018.
 */
public abstract class B8 {  //Abstract Class
    public int field8 = 1;
    public abstract boolean D2();
}

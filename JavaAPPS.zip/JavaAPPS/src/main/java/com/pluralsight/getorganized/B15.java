package com.pluralsight.getorganized;

/**
 * Created by abhijit on 27-05-2018.
 */
public class B15 extends B8{ //Abstract Class

    @Override
    public boolean D2(){
        System.out.println("equal");
        return true;
    }
}

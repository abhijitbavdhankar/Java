package com.pluralsight.getorganized.after_refactor;

import java.util.List;

public interface SalesRepository {

    List<Sale> loadSales();

}

package com.pluralsight.getorganized.guice;

import java.util.List;

public interface SalesRepository {

    public List<Sale> loadSales();

}

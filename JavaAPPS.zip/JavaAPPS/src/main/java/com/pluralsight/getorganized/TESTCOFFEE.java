package com.pluralsight.getorganized;

/**
 * Created by abhijit on 28-05-2018.
 */
public final class TESTCOFFEE {

    private final TESTCOFFEETYPE type;
    private final int beans;
    private final int milk;

    public TESTCOFFEE(TESTCOFFEETYPE coffeeType, int beans, int milk) {
        this.type = coffeeType;
        this.beans = beans;
        this.milk = milk;
    }

    public TESTCOFFEETYPE getType() {
        return type;
    }

    public int getBeans() {
        return beans;
    }

    public int getMilk() {
        return milk;
    }

    @Override
    public String toString() {
        return "Coffee{" +
                "type=" + type +
                ", beans=" + beans +
                ", milk=" + milk +
                '}';
    }


}

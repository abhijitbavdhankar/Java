package com.pluralsight.getorganized;

/**
 * Created by abhijit on 27-05-2018.
 */
/**
 * Created by abhijit on 27-05-2018.
 */
public class B extends A
{
    public B(int i)
    {
        super(i);
    }

    public void add(B b1) {
        System.out.println("Derived class");
    }
}

package com.pluralsight.getorganized.before_refactor;

import java.util.List;

public interface SalesRepository {

    public List<Sale> loadSales();

}

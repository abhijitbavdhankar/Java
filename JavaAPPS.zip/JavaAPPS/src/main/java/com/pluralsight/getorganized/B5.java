package com.pluralsight.getorganized;

/**
 * Created by abhijit on 27-05-2018.
 */
final public class B5 {
    private int str, str2;
    public int field = 1;

    public final void D() {
        System.out.println("default");
    }
}

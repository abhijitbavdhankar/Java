package com.pluralsight.getorganized;

/**
 * Created by abhijit on 27-05-2018.
 */
public class A implements Cloneable{

    private int i,k = 10;   //Field intialization, Initial Block , Constructor
    private int str,str2;
    public int field = 1;
    //Initialization Block
    public int getfield(){ return field;}
    {
        field = 2;
    }
    //Initialization Block
    private boolean[] j;
    {
        j = new boolean[k];
        for(int m=0; m < k; m++)
            j[i] =  true;
    }

    @Override
    public boolean equals(Object o)
    {
        if(super.equals(o))
            return true;

        if(!( o instanceof A)) //instanceof
            return false;

        A other = (A) o;
        return i == other.i && k == other.k;
    }

    public Object clone() throws CloneNotSupportedException
    {
        return super.clone();
    }

    public A(){}

    public A(int i){
        //this(i > 1 ? 25 : 50);
        this.i = i;
    }
    public A(int i,int str){
        //this(i);
        this();
        this.str = 10;
    } //this(i) will call constructor public A(int i)


    public int getString()
    {
        return str;
    }

    public void setString(int s)
    {
        this.str = s;
    }


    public void add()
    {
        i+=10;
        System.out.println(i);
        if(i > 15)
            return;
    }

    public void add(A a1)
    {
        int t = i+a1.i;
        System.out.println(t);
        if(t > 15)
            return;
    }


}



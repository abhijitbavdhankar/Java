package com.pluralsight.getorganized;
import java.util.*;

public class Main {

    public static void main(String[] args) throws CloneNotSupportedException{
	// write your code here
        System.out.println("Hi");
        int a = 10, b = 5, sum = 0;
        int[] c ={10,20,30};
        System.out.println(a);
        if( 1 > 10)
            System.out.println("0");
        else
            System.out.println("1");
        if( 1 > 10)
            System.out.println("0");
        else if(1 < 10)
            System.out.println("1");
        else
            System.out.println("2");
        if ( 1 < 10)
            if ( 1 == 1)
                System.out.println("3");
        if ( a > b & a > 30 | a > 5)
            System.out.println("4");
        if ( 0 > 0 && 150/0 > 30) //||
            System.out.println("5");
        for(int i : c) //c is array
            sum += i;
        System.out.println(sum);

        int val =10;
        switch(val % 2) {
            case 0:
                System.out.println("case 0 even");
            case 1:
                System.out.println("case 1 odd");
            default:
                System.out.println("default");
        }

        A objA =  new A(); //Class
        objA.add();
        objA.getfield();
        System.out.println(objA.field);
        objA.setString(100);
        System.out.println(objA.getString());
        A objA2 =  new A(); //Class
        objA2.add();
        objA2.add(objA2);
        A objA3 =  new A(10,20); //Class

        if( objA instanceof A){ //instanceof
            System.out.println("default");
        }
        if(objA.equals(objA2)) //if(objA == objA2) doesnot point to same object
            System.out.println("equal");

        A objA4 = new A();
        objA4 = (A)objA3.clone();

        //final no overriding and inheriting
        //abstract requires overriding and inheriting

        A objA5 =  new A();

        B5 b2  = new B5(); //final
        b2.D();

        B15 b8 =  new B15(); //abstract class
        b8.D2();



        //objA4.finalize();



    }
}

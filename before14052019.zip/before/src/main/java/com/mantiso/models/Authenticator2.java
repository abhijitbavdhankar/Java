package com.mantiso.models;

public class Authenticator2 {
	
	public String authenticate(String firstname, String lastname) {
		if (("prasad".equalsIgnoreCase(firstname))
				&& ("password".equals(lastname))) {
			return "success";
		} else {
			return "failure";
		}
	}

}

package com.mantiso.controllers;

import java.io.IOException;
//import java.util.Optional;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
//import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.mantiso.models.StudentService;
import com.mantiso.models.Authenticator2;
import com.mantiso.models.Student;

/**
* fffff
 * Servlet implementation class StudentController
 */

//@WebServlet( name = "StudentServlet",  urlPatterns = "/student")
public class StudentController extends HttpServlet {		 

	private static final long serialVersionUID = 1L;	
	private StudentService studentService = new StudentService();
	
	public StudentController() 
	{
		super();
	}
	/*
	 
	private void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{	    	
		
        String studentID = request.getParameter("id");
        if (studentID != null) {
            int id = Integer.parseInt(studentID);
            Student x = (Student)studentService.getStudent2(id);
            request.setAttribute("studentRecord", x);
            
            //  .ifPresent(s -> request.setAttribute("studentRecord", s));
        }
			
		
		System.exit(1);
				    			
	}*/	
		 
		    @Override
		    protected void doGet(
		      HttpServletRequest request, HttpServletResponse response) 
		      throws ServletException, IOException {	
		    	
		    	
		    	
		    	Student user = null;

		    	String id = request.getParameter("id");
		    	String firstname = request.getParameter("firstname");
		    	String lastname = request.getParameter("lastname");
		    	user = new Student(id, firstname, lastname);		    	
		    	
		    	Student user1 = (Student)studentService.getStudent2();
		    	
		    	if(user == null || user1 == null) 
    			{
		    		user = new Student("1", "Max", "Born");
    			}
		    	
		    	id = user.getId();
		    	firstname = user.getFirstName();
		    	lastname = user.getLastName();
		    	
		    	RequestDispatcher rd = null;
		    	
		    	Authenticator2 authenticator = new Authenticator2();				
				String result = authenticator.authenticate(firstname, lastname);
	            
				if (result.equals("success"))
	    		{		    	
			    	rd = getServletContext().getRequestDispatcher("/success2.jsp");
			    	getServletContext().setAttribute("user", user);
			    	request.setAttribute("user", user);
	    			request.getSession().setAttribute("user", user);
	    		}
    			else 
	    		{
	    			rd = request.getRequestDispatcher("/error.jsp");
	    		}
		    	//rd.include(request, response);
		    	rd.forward(request, response);	
		    	
		    	//processRequest(request, response);
		    }
		 
		    @Override
		    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
		      throws ServletException, IOException {
		 
		        //processRequest(request, response);
		    	/*
		    	Student user = (Student)request.getSession().getAttribute("user");		    	
		    	
		    	String id = user.getId();
		    	String firstname = user.getFirstName();
		    	String lastname = user.getLastName();
		    	
		    	//rd = request.getRequestDispatcher("/WEB-INF/student-record.jsp");
					//Student user = new Student("1", "Max", "Born");
					//user = new Student("1", "Max", "Born");
		    	*/
		    	
		    	Student user = null;
		    	
		    	if (request.getAttribute("user") != null) 
		    	{
		    		user = (Student)request.getSession().getAttribute("user");	
		    	}
		    	
		    	String id = request.getParameter("id");
		    	String firstname = request.getParameter("firstname");
		    	String lastname = request.getParameter("lastname");
		 
				RequestDispatcher rd = null;	
				Authenticator2 authenticator = new Authenticator2();				
				String result = authenticator.authenticate(firstname, lastname);
	            
				if (result.equals("success"))
	    		{	            	
	    			rd = request.getRequestDispatcher("/success2.jsp");
	    			
	    			if(user == null) 
	    			{
	    				user = new Student(id, firstname, lastname);
	    			}	    			
	    			request.setAttribute("user", user);
	    			request.getSession().setAttribute("user", user);
	    		} 
	    		else 
	    		{
	    			rd = request.getRequestDispatcher("/error.jsp");
	    		}
	    		rd.forward(request, response);
	    		//rd.include(request, response); //wait for processing
	    		//rd.sendRedirect("/success2.jsp"); //other domains
	    		
	    		//processRequest(request, response);
		    }
		    
		}
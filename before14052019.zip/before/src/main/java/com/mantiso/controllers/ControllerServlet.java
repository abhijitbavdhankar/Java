package com.mantiso.controllers;

//import org.omg.DynamicAny._DynAnyFactoryStub;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.ArrayList;
//import java.util.HashMap;
import java.util.List;
//import java.util.Map;
//import javax.jws.soap.InitParam;
//import javax.servlet.annotation.WebInitParam;
//import javax.servlet.annotation.WebServlet;
import com.mantiso.models.ApplicationSettings;
import com.mantiso.models.CssClass;
import com.mantiso.models.User;
import com.mantiso.models.Tab;
//import java.util.HashMap;
//import java.util.Map;
//import com.mantiso.models.User;

public class ControllerServlet extends HttpServlet {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Override
    public void init() throws ServletException {
		ApplicationSettings applicationSettings = new ApplicationSettings("brownUser");
        CssClass cssClass = new CssClass();
        cssClass.setName("yellowUser");
        applicationSettings.setFormCssClass1(cssClass);
                
        List<Tab> tabs = new ArrayList<>();
        tabs.add(new Tab("Signin", "#signin"));
        tabs.add(new Tab("Home", "#home"));
        tabs.add(new Tab("Profile", "#profile"));
        tabs.add(new Tab("Messages", "#messages"));
        tabs.add(new Tab("Settings", "#settings"));
        applicationSettings.setTabs(tabs);
        
        String[] tabNames = {"SignIn", "Home", "Profile", "Settings"};
        applicationSettings.setTabNames(tabNames);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	String name = "AB";
        String email = "a@b.com";
    	User user = new User(name, email);
        
        RequestDispatcher dispatcher = getServletContext().getRequestDispatcher("/WEB-INF/index.jsp");
        request.setAttribute("user", user);
        dispatcher.forward(request, response);
    }
}

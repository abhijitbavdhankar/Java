package com.monotonic.testing.m5.after_refactor;

import com.monotonic.testing.m5.*;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockSettings;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.ArgumentCaptor;
import org.junit.Assert;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

/**
 * Created by abhijit on 09-06-2018.
 */
public class OrderServiceImplTest {

    private final static long CUSTOMER_ID = 1;

    private OrderServiceImpl target = null;

    protected @Mock OrderDao mockOrderDao;
    protected @Mock OrderEntityToOrderSummaryTransformer mockTransformer;

    @Before
    public void setup() {
        MockitoAnnotations.initMocks(this);

        this.target = new OrderServiceImpl();
        this.target.setOrderDao(mockOrderDao);
        this.target.setTransformer(mockTransformer);
    }

    @Test
    public void test_openNewOrder_successfullyRetriesDataInsert() throws Exception {

        // Setup
        Mockito.when(mockOrderDao.insert(Mockito.any(OrderEntity.class)))
                .thenThrow(new DataAccessException("First Ex")).thenReturn(1);

        // Execution
        this.target.openNewOrder(CUSTOMER_ID);

        // Verification
        Mockito.verify(mockOrderDao, Mockito.times(2)).insert(Mockito.any(OrderEntity.class));

    }

    @Test(expected=ServiceException.class)
    public void test_openNewOrder_failedDataInsert() throws Exception {

        // Setup
        Mockito.when(mockOrderDao.insert(Mockito.any(OrderEntity.class)))
                .thenThrow(new DataAccessException("First Ex"))
                .thenThrow(new DataAccessException("Second Ex"));

        try {
            // Execution
            this.target.openNewOrder(CUSTOMER_ID);
        }
        finally
        {
            // Verification
            Mockito.verify(mockOrderDao, Mockito.times(2))
                    .insert(Mockito.any(OrderEntity.class));
        }
    }

    @Test
    public void test_openNewOrder_success() throws Exception {

        // Setup
        Mockito.when(mockOrderDao.insert(Mockito.any(OrderEntity.class)))
                .thenReturn(1);

        // Execution
        String orderNumber = this.target.openNewOrder(CUSTOMER_ID);

        // Verification
        ArgumentCaptor<OrderEntity> orderEntityCaptor =
                ArgumentCaptor.forClass(OrderEntity.class);
        Mockito.verify(mockOrderDao).insert(orderEntityCaptor.capture());

        OrderEntity capturedOrderEntity = orderEntityCaptor.getValue();

        Assert.assertNotNull(capturedOrderEntity);
        Assert.assertEquals(CUSTOMER_ID, capturedOrderEntity.getCustomerId());
        Assert.assertEquals(orderNumber, capturedOrderEntity.getOrderNumber());
    }
}

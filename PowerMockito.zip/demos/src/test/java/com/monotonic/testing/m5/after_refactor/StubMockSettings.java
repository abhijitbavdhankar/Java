package com.monotonic.testing.m5.after_refactor;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mock;
import org.mockito.MockSettings;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
/**
 * Created by abhijit on 07-06-2018.
 */
/**
 * Created by abhijit on 07-06-2018.
 */
public class StubMockSettings {

    private static final List<Sale> exampleSales = Arrays.asList(
            new Sale("Apples", "Cardiff", 10, 2),
            new Sale("Oranges", "Cardiff", 3, 5),
            new Sale("Bananas", "Cardiff", 6, 20),
            new Sale("Oranges", "London", 5, 7)
    );

    private static final Map<String, Integer> expectedStoreSales = new HashMap<>();
    static {
        expectedStoreSales.put("Cardiff", 155);
        expectedStoreSales.put("London", 35);
    }

    private SalesRepository stubRepository;

    @Test
    public void shouldStoreSales() {

        // given
        MockSettings settings = Mockito.withSettings();
        stubRepository = Mockito.mock(SalesRepository.class, settings);
        when(stubRepository.loadSales()).thenReturn(exampleSales);

        SalesAnalysisService analysisService = new SalesAnalysisService(stubRepository);

        // when
        Map<String, Integer> storeSales = analysisService.tallyStoreSales();

        // then
        assertEquals("Calculated wrong store sales", expectedStoreSales, storeSales);

        //
        //MockSettings settings = Mockito.withSettings();
        //SalesRepository stubRepository3 = Mockito.mock(SalesRepository.class, settings);
    }


}

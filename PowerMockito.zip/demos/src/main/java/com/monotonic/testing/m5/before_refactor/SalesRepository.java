package com.monotonic.testing.m5.before_refactor;

import java.util.List;

public interface SalesRepository {

    public List<Sale> loadSales();

}
